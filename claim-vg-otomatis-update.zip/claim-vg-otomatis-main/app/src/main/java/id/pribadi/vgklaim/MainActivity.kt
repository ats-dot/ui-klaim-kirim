package id.pribadi.vgklaim

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private var tab = 0

    // Area aman (status bar, poni, bilah navigasi) dan papan ketik
    private var topInset = 0
    private var botInset = 0
    private var kbOpen = false
    private var imeAnim: ValueAnimator? = null

    private var rootV: FrameLayout? = null
    private var bodyV: FrameLayout? = null
    private var helpOv: View? = null
    private var toastView: View? = null
    private var pagerLp: FrameLayout.LayoutParams? = null
    private var dockV: FrameLayout? = null
    private var dockLp: FrameLayout.LayoutParams? = null
    private var dockShown = true
    private val padViews = ArrayList<View>()

    // Beranda: Klaim VG
    private var cDot: StatusDot? = null
    private var cStatus: TextView? = null
    private var cProg: TextView? = null
    private var cBar: GlowBar? = null
    private var cAct: ActionButton? = null
    private var lastFracC = -1f

    // Beranda: Kirim BBC
    private var bDot: StatusDot? = null
    private var bStatus: TextView? = null
    private var bProg: TextView? = null
    private var bBar: GlowBar? = null
    private var bAct: ActionButton? = null
    private var lastFracB = -1f

    // Isian Jumlah server dipakai bersama di dua halaman
    private val cntFields = ArrayList<FloatField>()

    private var tvLog: TextView? = null
    private var logScroll: ScrollView? = null
    private var tvLogStatus: TextView? = null
    private var tvSvc: TextView? = null
    private var tvBat: TextView? = null
    private var tvAuto: TextView? = null
    private var tvNotif: TextView? = null
    private var izinIcon: ImageView? = null
    private var izinState = 0
    private var focusSink: View? = null
    private var lastLog = ""
    private val swipeFields = ArrayList<Pair<EditText, () -> Int>>()

    // Pager antar tab
    private var pager: Pager? = null
    private var pages = ArrayList<View>()
    private var pos = 0f
    private var posAnim: ValueAnimator? = null
    private var thumbAnim: ValueAnimator? = null
    private var thumbPos = 0f
    private var dockThumb: View? = null
    private var dockBtnW = 0
    private var dockIcons = ArrayList<TabIcon>()
    private var dockLabels = ArrayList<TextView>()
    private var modeViews = ArrayList<View>()
    private val argb = ArgbEvaluator()

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        Matcher.reload(applicationContext)
        AutoAccess.ensure(applicationContext)
        // Papan ketik tidak muncul sendiri saat aplikasi dibuka atau dibuka lagi (hanya saat kotak diketuk)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        // Layar penuh: latar kaca terlihat sampai di bawah status bar dan bilah navigasi, isi dijaga dari area aman
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.isNavigationBarContrastEnforced = false
        val wlp = window.attributes
        wlp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = wlp
        val askedNotif = askNotif()
        render()
        // Dialog izin notifikasi dan dialog baterai tidak boleh bertumpuk: baterai menunggu hasil izin notifikasi
        if (!askedNotif) h.postDelayed({ askBatteryOnce() }, 700)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) h.postDelayed({ askBatteryOnce() }, 400)
    }

    // Dialog sistem sekali ketuk "Izinkan aplikasi berjalan di latar belakang" (tanpa batasan baterai)
    private fun askBattery() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                i.data = android.net.Uri.parse("package:" + packageName)
                startActivity(i)
            }
        } catch (e: Throwable) {
            toast("Tidak bisa membuka dialog baterai: " + e.javaClass.simpleName)
        }
    }

    private fun askBatteryOnce() {
        if (Prefs.batteryAsked) return
        Prefs.batteryAsked = true
        askBattery()
    }

    // Izin notifikasi (Android 13 ke atas) diminta begitu aplikasi dibuka. Sistem hanya menampilkan dialognya kalau izin belum
    // diberikan dan belum ditolak permanen; kalau sudah ditolak permanen, ketuk baris Notifikasi di Pengaturan
    private fun askNotif(): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 11)
            return true
        }
        return false
    }

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Throwable) {
            toast("Tidak bisa dibuka: " + e.javaClass.simpleName)
        }
    }

    // Tutup papan ketik dan lepaskan fokus dari kotak isian, supaya papan ketik tidak muncul lagi sendiri
    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(window.decorView.windowToken, 0)
            currentFocus?.clearFocus()
            focusSink?.requestFocus()
        } catch (e: Throwable) {
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f is EditText) {
                val r = Rect()
                f.getGlobalVisibleRect(r)
                if (!r.contains(ev.rawX.toInt(), ev.rawY.toInt())) hideKeyboard()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        AutoAccess.ensure(applicationContext)
        h.post(ticker)
    }

    override fun onPause() {
        hideKeyboard()
        super.onPause()
        h.removeCallbacks(ticker)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (helpOv != null) {
            closeHelp()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- bahan tampilan ----------

    private fun shape(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Float = 1.5f): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        if (strokeDp > 0f) g.setStroke(maxOf(1, (strokeDp * resources.displayMetrics.density).toInt()), stroke)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    // Kotak dialog: kaca gelap. Kalau perangkat bisa mengaburkan latar, isinya dibuat sedikit lebih tembus
    private fun popBg(radiusDp: Int): Drawable {
        val a = if (Build.VERSION.SDK_INT >= 31) 224 else 250
        return GlassDrawable(dp(radiusDp).toFloat(), dp(1).toFloat(), Color.argb(a, 20, 22, 28))
    }

    private fun silverPill(radiusDp: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C_ACC, C_ACC2))
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun btn(t: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        b.setTypeface(null, Typeface.BOLD)
        b.stateListAnimator = null
        b.minHeight = 0
        b.minimumHeight = 0
        if (primary) {
            b.background = silverPill(30)
            b.setTextColor(C_ONACC)
            attachPress(b, 0.965f, null)
        } else {
            val g = GlassDrawable(dp(30).toFloat(), dp(1).toFloat())
            b.background = g
            b.setTextColor(C_FG)
            attachPress(b, 0.965f, g)
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun tv(t: String, size: Float = 15f, bold: Boolean = false, color: Int = C_FG): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }

    private fun card(vararg views: View): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(4), dp(18), dp(4))
        c.background = GlassDrawable(dp(26).toFloat(), dp(1).toFloat())
        for (v in views) c.addView(v)
        return c
    }

    private fun glassCard(l: Int, t: Int, r: Int, b: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(l), dp(t), dp(r), dp(b))
        c.clipToPadding = false
        c.clipChildren = false
        c.background = GlassDrawable(dp(26).toFloat(), dp(1).toFloat())
        return c
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(C_DIV)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxOf(1, dp(1)))
        return v
    }

    // Satu baris: label di kiri, kontrol di kanan
    private fun row(label: String, right: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(52)
        r.addView(tv(label, 16f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val rp = (right.layoutParams as? LinearLayout.LayoutParams)
            ?: LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rp.leftMargin = dp(12)
        r.addView(right, rp)
        return r
    }

    private fun linkRow(label: String, value: TextView, onClick: () -> Unit): View {
        val r = row(label, value)
        attachRowPress(r)
        r.setOnClickListener { onClick() }
        return r
    }

    private fun switchRow(label: String, get: () -> Boolean, set: (Boolean) -> Unit): View {
        val sw = GlassSwitch(this)
        sw.set(get())
        sw.onChange = { v -> set(v) }
        sw.contentDescription = label
        val r = row(label, sw)
        attachRowPress(r)
        r.setOnClickListener { sw.performClick() }
        return r
    }

    // Kotak angka kecil (Pengaturan): latar memudar halus saat difokus, tersimpan otomatis tiap diubah
    private fun numBox(value: String, widthDp: Int = 84, onChange: ((String) -> Unit)? = null): EditText {
        val e = EditText(this)
        e.setText(value)
        e.setTextColor(C_FG)
        e.setHintTextColor(C_MUT)
        e.gravity = Gravity.CENTER
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        e.typeface = Typeface.DEFAULT_BOLD
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setSingleLine(true)
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            true
        }
        val fd = FieldDrawable(dp(21).toFloat(), maxOf(1f, resources.displayMetrics.density))
        e.background = fd
        e.setOnFocusChangeListener { _, has -> fd.setFocused(has) }
        e.setPadding(dp(8), 0, dp(8), 0)
        e.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(42))
        if (onChange != null) {
            e.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    onChange(s?.toString() ?: "")
                }
            })
        }
        return e
    }

    // Pilihan geser: penanda perak meluncur dengan sedikit pantulan, warna teks ikut berganti halus
    private fun seg(options: List<String>, selected: Int, heightDp: Int, textSp: Float, onPick: (Int) -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val pad = dp(4)
        f.background = GlassDrawable(dp(heightDp / 2).toFloat(), dp(1).toFloat())
        f.setPadding(pad, pad, pad, pad)
        val n = options.size
        val th = View(this)
        th.background = silverPill(heightDp / 2)
        f.addView(th, FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT))
        val rowV = LinearLayout(this)
        rowV.orientation = LinearLayout.HORIZONTAL
        val labels = ArrayList<TextView>()
        var cur = selected
        var segW = 0
        for (k in 0 until n) {
            val t = tv(options[k], textSp, true, if (k == selected) C_ONACC else C_FG)
            t.gravity = Gravity.CENTER
            attachRowPress(t)
            t.setOnClickListener {
                if (cur != k) {
                    cur = k
                    for (j in labels.indices) {
                        val lab = labels[j]
                        val to = if (j == k) C_ONACC else C_FG
                        val a = ValueAnimator.ofArgb(lab.currentTextColor, to)
                        a.duration = 260
                        a.addUpdateListener { lab.setTextColor(it.animatedValue as Int) }
                        a.start()
                    }
                    th.animate().translationX((k * segW).toFloat()).setDuration(400).setInterpolator(OvershootInterpolator(0.8f)).start()
                    onPick(k)
                }
            }
            labels.add(t)
            rowV.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        f.addView(rowV, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        f.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = (r - l - 2 * pad) / n
            if (w > 0 && w != segW) {
                segW = w
                th.layoutParams = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT)
                th.translationX = (cur * w).toFloat()
            }
        }
        return f
    }

    private fun lpw(hDp: Int, topDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (hDp > 0) dp(hDp) else ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.setMargins(0, dp(topDp), 0, 0)
        return p
    }

    private fun section(title: String, body: View): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val t = tv(title, 13f, true, C_MUT)
        t.isAllCaps = true
        t.letterSpacing = 0.06f
        t.setPadding(dp(8), 0, 0, dp(10))
        c.addView(t)
        c.addView(body)
        return c
    }

    private fun page(dockPad: Boolean = true): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(8), dp(18), dp(104) + botInset)
        sv.addView(col)
        if (dockPad) padViews.add(col)
        return Pair(sv, col)
    }

    // Pesan singkat berbentuk pil kaca yang naik dan pudar (pengganti Toast sistem di layar utama)
    private fun toast(m: String) {
        val r = rootV
        if (r == null) {
            Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
            return
        }
        val old = toastView
        if (old != null) {
            old.animate().cancel()
            (old.parent as? ViewGroup)?.removeView(old)
        }
        val t = TextView(this)
        t.text = m
        t.setTextColor(C_FG)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(20), dp(12), dp(20), dp(12))
        t.background = GlassDrawable(dp(22).toFloat(), dp(1).toFloat(), C_POP)
        t.maxWidth = (resources.displayMetrics.widthPixels * 0.86f).toInt()
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = dp(16) + botInset + dp(70) + dp(14)
        t.alpha = 0f
        t.translationY = dp(12).toFloat()
        r.addView(t, lp)
        toastView = t
        t.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(easeOut()).start()
        h.postDelayed({
            if (toastView === t) {
                t.animate().alpha(0f).translationY(dp(8).toFloat()).setDuration(200).withEndAction {
                    (t.parent as? ViewGroup)?.removeView(t)
                    if (toastView === t) toastView = null
                }.start()
            }
        }, 2400)
    }

    // Toast sistem untuk pesan yang muncul di atas dialog
    private fun sysToast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    // Teks yang berganti dengan pudar singkat
    private fun swapText(target: TextView?, s: String) {
        if (target == null || target.text.toString() == s) return
        if (target.text.isEmpty() || !target.isAttachedToWindow) {
            target.text = s
            return
        }
        target.animate().alpha(0.3f).setDuration(70).withEndAction {
            target.text = s
            target.animate().alpha(1f).setDuration(150).start()
        }.start()
    }

    // ---------- kerangka: header, pager, dock ----------

    private fun header(title: String, help: Boolean, back: Boolean): View {
        val hd = LinearLayout(this)
        hd.orientation = LinearLayout.HORIZONTAL
        hd.gravity = Gravity.CENTER_VERTICAL
        hd.setPadding(dp(26), dp(6), dp(18), 0)
        hd.minimumHeight = dp(64)
        if (back) {
            val b = FrameLayout(this)
            b.contentDescription = "Kembali"
            b.addView(iconView(this, R.drawable.ic_back, C_FG), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            attachRowPress(b)
            b.setOnClickListener { closeHelp() }
            val bp = LinearLayout.LayoutParams(dp(48), dp(48))
            bp.leftMargin = -dp(14)
            hd.addView(b, bp)
        }
        hd.addView(tv(title, 28f, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (help) {
            val hb = FrameLayout(this)
            val g = GlassDrawable(dp(21).toFloat(), dp(1).toFloat())
            hb.background = g
            hb.contentDescription = "Bantuan"
            hb.addView(iconView(this, R.drawable.ic_help, C_FG), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            attachPress(hb, 0.92f, g)
            hb.setOnClickListener { openHelp() }
            hd.addView(hb, LinearLayout.LayoutParams(dp(42), dp(42)))
        }
        return hd
    }

    // Posisi halaman (0 sampai 2, boleh pecahan saat digeser). Semua halaman, dock, dan ikon mengikuti angka ini.
    private fun applyPos(p: Float, drag: Boolean) {
        pos = p
        val w = (pager?.width ?: 0).toFloat()
        for (i in pages.indices) {
            val d = i - p
            val a = Math.abs(d)
            val v = pages[i]
            if (a >= 1f) {
                v.visibility = View.INVISIBLE
            } else {
                v.visibility = View.VISIBLE
                v.translationX = d * w
                v.alpha = 1f - 0.65f * a
                val s = 1f - 0.05f * a
                v.scaleX = s
                v.scaleY = s
            }
        }
        if (drag) setThumb(p)
        for (i in dockIcons.indices) {
            val k = (1f - Math.abs(i - p)).coerceIn(0f, 1f)
            val col = argb.evaluate(k, C_MUT, C_FG) as Int
            dockIcons[i].tint(col)
            dockLabels[i].setTextColor(col)
        }
        tab = Math.round(p).coerceIn(0, 2)
    }

    private fun setThumb(p: Float) {
        thumbPos = p
        dockThumb?.translationX = p * dockBtnW
    }

    private fun goTo(i: Int) {
        hideKeyboard()
        posAnim?.cancel()
        thumbAnim?.cancel()
        val a = ValueAnimator.ofFloat(pos, i.toFloat())
        a.duration = (360 + 160 * Math.abs(i - pos)).toLong()
        a.interpolator = easeOut()
        a.addUpdateListener { applyPos(it.animatedValue as Float, false) }
        a.start()
        posAnim = a
        val b = ValueAnimator.ofFloat(thumbPos, i.toFloat())
        b.duration = 560
        b.interpolator = OvershootInterpolator(1.0f)
        b.addUpdateListener { setThumb(it.animatedValue as Float) }
        b.start()
        thumbAnim = b
    }

    private inner class Pager(ctx: Context) : FrameLayout(ctx) {
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        private var x0 = 0f
        private var y0 = 0f
        private var drag = false
        private var startPos = 0f
        private var vt: VelocityTracker? = null

        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.x
                    y0 = e.y
                    drag = false
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    val dx = e.x - x0
                    val dy = e.y - y0
                    if (!drag && Math.abs(dx) > slop * 2 && Math.abs(dx) > Math.abs(dy) * 1.3f) {
                        drag = true
                        startPos = pos
                        posAnim?.cancel()
                        thumbAnim?.cancel()
                        parent?.requestDisallowInterceptTouchEvent(true)
                        x0 = e.x
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!drag) {
                        vt?.recycle()
                        vt = null
                    }
                }
            }
            return drag
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            vt?.addMovement(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_MOVE -> {
                    if (drag && width > 0) {
                        var p = startPos - (e.x - x0) / width
                        if (p < 0f) p *= 0.35f
                        if (p > 2f) p = 2f + (p - 2f) * 0.35f
                        applyPos(p, true)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (drag) {
                        vt?.computeCurrentVelocity(1000)
                        val v = vt?.xVelocity ?: 0f
                        val start = Math.round(startPos)
                        val moved = pos - start
                        var target = start
                        if (v < -700f || moved > 0.22f) target = start + 1
                        else if (v > 700f || moved < -0.22f) target = start - 1
                        goTo(target.coerceIn(0, 2))
                    }
                    drag = false
                    vt?.recycle()
                    vt = null
                }
            }
            return true
        }
    }

    private fun buildDock(): FrameLayout {
        val dockW = Math.min(resources.displayMetrics.widthPixels - dp(36), dp(400))
        dockBtnW = (dockW - dp(12)) / 3
        val dock = FrameLayout(this)
        dock.background = GlassDrawable(dp(35).toFloat(), dp(1).toFloat(), Color.argb(250, 12, 13, 17))
        val th = View(this)
        val tg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(46, 255, 255, 255), Color.argb(15, 255, 255, 255)))
        tg.cornerRadius = dp(29).toFloat()
        tg.setStroke(maxOf(1, dp(1)), Color.argb(34, 255, 255, 255))
        th.background = tg
        val tp = FrameLayout.LayoutParams(dockBtnW, dp(58))
        tp.leftMargin = dp(6)
        tp.topMargin = dp(6)
        dock.addView(th, tp)
        dockThumb = th

        val rowV = LinearLayout(this)
        rowV.orientation = LinearLayout.HORIZONTAL
        rowV.setPadding(dp(6), dp(6), dp(6), dp(6))
        dockIcons = ArrayList()
        dockLabels = ArrayList()
        val names = listOf("Beranda", "Log", "Pengaturan")
        for (i in names.indices) {
            val b = LinearLayout(this)
            b.orientation = LinearLayout.VERTICAL
            b.gravity = Gravity.CENTER
            val ic = TabIcon(this, i)
            val lb = tv(names[i], 11.5f, true, C_MUT)
            lb.gravity = Gravity.CENTER
            b.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            b.addView(lb, lpw(0, 3))
            dockIcons.add(ic)
            dockLabels.add(lb)
            b.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).setInterpolator(easeOut()).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(2f)).start()
                }
                false
            }
            b.setOnClickListener { goTo(i) }
            rowV.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        dock.addView(rowV, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val lp = FrameLayout.LayoutParams(dockW, dp(70))
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.bottomMargin = dp(16) + botInset
        dockLp = lp
        dock.layoutParams = lp
        dockV = dock
        return dock
    }

    // Dock turun dan pudar saat papan ketik muncul, naik lagi saat hilang
    private fun setDockShown(show: Boolean) {
        val d = dockV ?: return
        if (show == dockShown) return
        dockShown = show
        if (show) {
            d.visibility = View.VISIBLE
            d.animate().alpha(1f).setDuration(240).setInterpolator(easeOut()).start()
        } else {
            d.animate().alpha(0f).setDuration(120).withEndAction {
                if (!dockShown) d.visibility = View.INVISIBLE
            }.start()
        }
    }

    // Area halaman menyusut halus mengikuti papan ketik (dock tetap di dasar layar dan tertutup keyboard)
    private fun setImeMargin(target: Int) {
        val pl = pagerLp ?: return
        if (pl.bottomMargin == target) return
        imeAnim?.cancel()
        val a = ValueAnimator.ofInt(pl.bottomMargin, target)
        a.duration = 220
        a.interpolator = easeOut()
        a.addUpdateListener {
            pl.bottomMargin = it.animatedValue as Int
            pager?.layoutParams = pl
        }
        a.start()
        imeAnim = a
    }

    // Terapkan area aman: judul tidak tertutup status bar, dock dan isi tidak tertutup bilah navigasi
    private fun applyInsets() {
        val pl = pagerLp
        if (pl != null && pl.topMargin != topInset + dp(8)) {
            pl.topMargin = topInset + dp(8)
            pager?.layoutParams = pl
        }
        val dl = dockLp
        if (dl != null && dl.bottomMargin != dp(16) + botInset) {
            dl.bottomMargin = dp(16) + botInset
            dockV?.layoutParams = dl
        }
        for (v in padViews) v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, dp(104) + botInset)
    }

    private fun render() {
        cDot = null
        cStatus = null
        cProg = null
        cBar = null
        cAct = null
        bDot = null
        bStatus = null
        bProg = null
        bBar = null
        bAct = null
        tvLog = null
        logScroll = null
        tvLogStatus = null
        tvSvc = null
        tvBat = null
        tvAuto = null
        tvNotif = null
        izinIcon = null
        izinState = 0
        lastFracC = -1f
        lastFracB = -1f
        padViews.clear()
        cntFields.clear()
        swipeFields.clear()
        posAnim?.cancel()
        thumbAnim?.cancel()
        imeAnim?.cancel()
        dockShown = true
        toastView = null
        helpOv = null

        val root = FrameLayout(this)
        root.setBackgroundColor(C_BG)
        // Root memegang fokus supaya tidak ada kotak isian yang otomatis terfokus (papan ketik muncul sendiri)
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        focusSink = root
        root.addView(BackdropView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val body = FrameLayout(this)
        root.addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val pg = Pager(this)
        pager = pg
        pages = ArrayList()
        pages.add(pageHome())
        pages.add(pageLog())
        pages.add(pageSettings())
        for (p in pages) pg.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val pgp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        pgp.topMargin = topInset + dp(8)
        pagerLp = pgp
        body.addView(pg, pgp)

        body.addView(buildDock())

        var lastW = -1
        pg.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            if (r - l != lastW) {
                lastW = r - l
                applyPos(tab.toFloat(), true)
            }
        }
        applyPos(tab.toFloat(), true)

        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            val ime = ins.getInsets(WindowInsets.Type.ime()).bottom
            topInset = b.top
            botInset = b.bottom
            kbOpen = ime > 0
            applyInsets()
            setImeMargin(ime)
            setDockShown(!kbOpen)
            ins
        }
        rootV = root
        bodyV = body
        setContentView(root)
        window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )
        root.requestFocus()
        root.requestApplyInsets()
        applyInsets()
        tick()
    }

    // ---------- Beranda: pilihan Klaim VG / Kirim BBC ----------

    private fun pageHome(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val ms = seg(listOf("Klaim VG", "Kirim BBC"), Prefs.homeMode, 50, 15f) { m ->
            hideKeyboard()
            selectMode(m, true)
        }
        val mp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        mp.setMargins(dp(18), dp(6), dp(18), dp(4))
        col.addView(ms, mp)
        val frame = FrameLayout(this)
        modeViews = arrayListOf<View>(home(), bbcHome())
        frame.addView(modeViews[0], FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(modeViews[1], FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        col.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        selectMode(Prefs.homeMode, false)
        return col
    }

    private fun selectMode(m: Int, animate: Boolean) {
        Prefs.homeMode = m
        for (i in modeViews.indices) {
            val v = modeViews[i]
            val on = i == m
            val tx = if (on) 0f else if (i < m) -dp(28).toFloat() else dp(28).toFloat()
            v.animate().cancel()
            if (!animate) {
                v.alpha = if (on) 1f else 0f
                v.translationX = tx
                v.visibility = if (on) View.VISIBLE else View.INVISIBLE
            } else {
                if (on) v.visibility = View.VISIBLE
                v.animate().alpha(if (on) 1f else 0f).translationX(tx).setDuration(420).setInterpolator(easeOut())
                    .withEndAction { if (!on) v.visibility = View.INVISIBLE }.start()
            }
        }
        tick()
    }

    private fun statusRow(dot: StatusDot, st: TextView, prog: TextView): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        // Cincin titik rata dengan tepi kiri isi kartu; teks status mulai sejajar dengan teks di kotak isian (19dp dari tepi)
        val dpp = LinearLayout.LayoutParams(dp(18), dp(18))
        dpp.leftMargin = -dp(3)
        dpp.rightMargin = dp(4)
        r.addView(dot, dpp)
        // Teks status dan progres dibuat sejajar garis dasarnya
        val tr = LinearLayout(this)
        tr.orientation = LinearLayout.HORIZONTAL
        tr.isBaselineAligned = true
        tr.addView(st, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val pp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        pp.leftMargin = dp(10)
        tr.addView(prog, pp)
        r.addView(tr, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return r
    }

    private fun home(): View {
        val (sv, col) = page()

        val dot = StatusDot(this)
        cDot = dot
        val st = tv("", 18f, true, C_FG)
        st.maxLines = 2
        cStatus = st
        val prog = tv("", 13.5f, false, C_MUT)
        prog.fontFeatureSettings = "tnum"
        cProg = prog
        val bar = GlowBar(this)
        cBar = bar

        val cnt = FloatField(
            this, "Jumlah server", true,
            if (Prefs.serverCount > 0) Prefs.serverCount.toString() else "",
            { hideKeyboard() }
        ) { t ->
            t.trim().toIntOrNull()?.let { Prefs.serverCount = it }
        }
        cntFields.add(cnt)
        val chip = ToggleChip(this, "Topup")
        chip.set(Prefs.topUp)
        chip.onChange = { v -> Prefs.topUp = v }

        val card = glassCard(14, 16, 14, 14)
        card.addView(statusRow(dot, st, prog))
        card.addView(bar, lpw(7, 14))
        val fr = LinearLayout(this)
        fr.orientation = LinearLayout.HORIZONTAL
        fr.gravity = Gravity.CENTER_VERTICAL
        fr.addView(cnt, LinearLayout.LayoutParams(0, dp(52), 1f))
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        cp.leftMargin = dp(10)
        fr.addView(chip, cp)
        card.addView(fr, lpw(0, 16))
        col.addView(card, lpw(0, 0))

        val spacer = View(this)
        col.addView(spacer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val act = ActionButton(this, "MULAI KLAIM")
        cAct = act
        act.onStart = {
            val n = cnt.text().trim().toIntOrNull() ?: 0
            if (n < 2) {
                cnt.alert()
            } else {
                Prefs.serverCount = n
                begin(0)
            }
        }
        act.onStop = {
            Engine.stop()
            tick()
        }
        act.onEnable = { openAccessibility() }
        col.addView(act, lpw(58, 16))
        return sv
    }

    // Mulai proses: nyalakan Aksesibilitas otomatis bila izin sudah diberikan, lalu jalankan
    private fun begin(mode: Int) {
        hideKeyboard()
        askNotif()
        val changed = AutoAccess.ensure(applicationContext)
        val go = {
            val r = if (mode == 1) Engine.start(applicationContext, 1) else Engine.start(applicationContext)
            if (r != null) toast(r)
            tick()
        }
        // Kalau Aksesibilitas baru dinyalakan (atau sedang tersambung), tunggu sampai layanan benar-benar tersambung, maksimal 10 detik.
        // Begitu tersambung, langsung jalan
        if (changed || (ClaimService.inst == null && AutoAccess.granted(applicationContext))) {
            var waited = 0
            val poll = object : Runnable {
                override fun run() {
                    if (ClaimService.inst != null) {
                        go()
                        return
                    }
                    waited += 100
                    if (waited >= 10000) {
                        toast("Aksesibilitas belum tersambung, coba lagi")
                        return
                    }
                    h.postDelayed(this, 100)
                }
            }
            h.postDelayed(poll, 100)
        } else {
            go()
        }
    }

    // Stepper jumlah BBC (dalam ribuan): tombol minus dan plus (tahan untuk mengulang) serta angka yang bisa diketik
    private fun bbcStepper(): LinearLayout {
        val rowL = LinearLayout(this)
        rowL.orientation = LinearLayout.HORIZONTAL
        rowL.gravity = Gravity.CENTER_VERTICAL
        rowL.setPadding(dp(7), 0, dp(7), 0)
        rowL.background = GlassDrawable(dp(29).toFloat(), dp(1).toFloat())

        val num = EditText(this)
        num.setText((Prefs.bbcAmount / 1000).toString())
        num.setTextColor(C_FG)
        num.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
        num.typeface = Typeface.DEFAULT_BOLD
        num.background = null
        num.gravity = Gravity.CENTER
        num.inputType = InputType.TYPE_CLASS_NUMBER
        num.setSingleLine(true)
        num.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(4))
        num.imeOptions = EditorInfo.IME_ACTION_DONE
        num.minWidth = dp(12)
        num.includeFontPadding = false
        num.fontFeatureSettings = "tnum"
        num.setPadding(dp(10), dp(8), 0, dp(8))
        num.contentDescription = "Jumlah BBC dalam ribuan"
        num.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            true
        }
        num.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val k = (s?.toString() ?: "").trim().toIntOrNull() ?: 0
                Prefs.bbcAmount = k * 1000
                tick()
            }
        })
        val kTv = tv("k", 24f, true, C_MUT)
        kTv.includeFontPadding = false
        kTv.setPadding(dp(3), dp(8), dp(10), dp(8))

        fun delta(dv: Int) {
            val cur = num.text.toString().trim().toIntOrNull() ?: 0
            val nv = (cur + dv).coerceIn(0, 9999)
            if (nv != cur) {
                num.setText(nv.toString())
                num.setSelection(num.text.length)
                num.animate().cancel()
                num.animate().scaleX(1.08f).scaleY(1.08f).setDuration(70).withEndAction {
                    num.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(OvershootInterpolator(2f)).start()
                }.start()
            }
        }

        fun stepBtn(res: Int, label: String, dv: Int): FrameLayout {
            val b = FrameLayout(this)
            val g = GlassDrawable(dp(22).toFloat(), dp(1).toFloat())
            b.background = g
            b.contentDescription = label
            b.addView(iconView(this, res, C_FG), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            val rt = RepeatTouch(h, g) { delta(dv) }
            b.setOnTouchListener(rt)
            b.setOnClickListener {
                if (!rt.consumeClick()) delta(dv)
            }
            return b
        }

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        mid.gravity = Gravity.CENTER
        mid.addView(num, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        mid.addView(kTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        rowL.addView(stepBtn(R.drawable.ic_minus, "Kurangi", -1), LinearLayout.LayoutParams(dp(44), dp(44)))
        rowL.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        rowL.addView(stepBtn(R.drawable.ic_plus, "Tambah", 1), LinearLayout.LayoutParams(dp(44), dp(44)))
        return rowL
    }

    private fun bbcHome(): View {
        val (sv, col) = page()

        val dot = StatusDot(this)
        bDot = dot
        val st = tv("", 18f, true, C_FG)
        st.maxLines = 2
        bStatus = st
        val prog = tv("", 13.5f, false, C_MUT)
        prog.fontFeatureSettings = "tnum"
        bProg = prog
        val bar = GlowBar(this)
        bBar = bar

        val idF = FloatField(this, "ID penerima", true, Prefs.bbcId, { hideKeyboard() }) { t -> Prefs.bbcId = t.trim() }
        val nickF = FloatField(this, "Nick penerima", false, Prefs.bbcNick, { hideKeyboard() }) { t -> Prefs.bbcNick = t }
        val stepper = bbcStepper()
        val startF = FloatField(
            this, "Mulai dari server", true,
            if (Prefs.bbcStartFrom > 0) Prefs.bbcStartFrom.toString() else "",
            { hideKeyboard() }
        ) { t -> Prefs.bbcStartFrom = t.trim().toIntOrNull() ?: 0 }
        val cnt = FloatField(
            this, "Jumlah server", true,
            if (Prefs.serverCount > 0) Prefs.serverCount.toString() else "",
            { hideKeyboard() }
        ) { t ->
            t.trim().toIntOrNull()?.let { Prefs.serverCount = it }
        }
        cntFields.add(cnt)
        val c1 = ToggleChip(this, "Cocokkan nick")
        c1.set(Prefs.bbcMatchNick)
        c1.onChange = { v -> Prefs.bbcMatchNick = v }
        val c2 = ToggleChip(this, "Klaim dulu")
        c2.set(Prefs.bbcClaimFirst)
        c2.onChange = { v -> Prefs.bbcClaimFirst = v }

        val card = glassCard(14, 16, 14, 14)
        card.addView(statusRow(dot, st, prog), lpw(0, 0))
        card.addView(bar, lpw(7, 14))

        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        val lpa = LinearLayout.LayoutParams(0, dp(52), 1f)
        lpa.rightMargin = dp(5)
        val lpb = LinearLayout.LayoutParams(0, dp(52), 1f)
        lpb.leftMargin = dp(5)
        r1.addView(idF, lpa)
        r1.addView(nickF, lpb)
        card.addView(r1, lpw(0, 16))

        card.addView(stepper, lpw(58, 10))

        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        val lpc = LinearLayout.LayoutParams(0, dp(52), 1f)
        lpc.rightMargin = dp(5)
        val lpd = LinearLayout.LayoutParams(0, dp(52), 1f)
        lpd.leftMargin = dp(5)
        r2.addView(startF, lpc)
        r2.addView(cnt, lpd)
        card.addView(r2, lpw(0, 10))

        val r3 = LinearLayout(this)
        r3.orientation = LinearLayout.HORIZONTAL
        val lpe = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        lpe.rightMargin = dp(10)
        r3.addView(c1, lpe)
        r3.addView(c2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        card.addView(r3, lpw(0, 10))
        col.addView(card, lpw(0, 0))

        val spacer = View(this)
        col.addView(spacer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val act = ActionButton(this, "MULAI KIRIM")
        bAct = act
        act.onStart = {
            val id = Prefs.bbcId.trim()
            if (id.isEmpty() || !id.all { it.isDigit() }) {
                idF.alert()
            } else if (Prefs.bbcAmount <= 0) {
                shake(stepper, dp(7).toFloat())
            } else if (Prefs.bbcMatchNick && Prefs.bbcNick.trim().isEmpty()) {
                nickF.alert()
            } else if (Prefs.serverCount < 2) {
                cnt.alert()
            } else {
                begin(1)
            }
        }
        act.onStop = {
            Engine.stop()
            tick()
        }
        act.onEnable = { openAccessibility() }
        col.addView(act, lpw(58, 16))
        return sv
    }

    // ---------- tab Log ----------

    private fun pageLog(): View {
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.addView(header("Log", false, false))
        outer.addView(logTab(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return outer
    }

    private fun logTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(4), dp(18), dp(104) + botInset)
        padViews.add(col)

        val rowB = LinearLayout(this)
        rowB.orientation = LinearLayout.HORIZONTAL
        val b1 = btn("Salin log") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", AppLog.text()))
            toast("Log disalin")
        }
        val b2 = btn("Hapus log") {
            AppLog.clear()
            lastLog = ""
            tick()
        }
        val b3 = btn("Diagnosa", true) {
            Engine.diagnose(applicationContext)
            toast("Pindah ke game dalam 15 detik, lalu diam")
        }
        for (b in listOf(b1, b2, b3)) {
            val p = LinearLayout.LayoutParams(0, dp(48), 1f)
            p.setMargins(dp(3), 0, dp(3), 0)
            rowB.addView(b, p)
        }
        col.addView(rowB)

        val st = tv("", 13f, false, C_MUT)
        tvLogStatus = st
        col.addView(st, lpw(0, 10))

        val t = tv("", 12f)
        t.typeface = Typeface.MONOSPACE
        t.setTextIsSelectable(true)
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        tvLog = t
        val sv = ScrollView(this)
        sv.background = GlassDrawable(dp(26).toFloat(), dp(1).toFloat())
        sv.addView(t)
        logScroll = sv
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).also { it.topMargin = dp(10) })
        return col
    }

    // ---------- tab Pengaturan ----------

    private fun gameShort(): String {
        val p = Prefs.pkg
        if (p.isEmpty()) return "Otomatis"
        for ((pk, lb) in Engine.listApps(this, true)) if (pk == p) return lb
        return p
    }

    private fun pageSettings(): View {
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.addView(header("Pengaturan", true, false))
        outer.addView(settings(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return outer
    }

    private fun notifOn(): Boolean {
        return try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).areNotificationsEnabled()
        } catch (e: Throwable) {
            true
        }
    }

    private fun batteryOk(): Boolean {
        return try {
            (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)
        } catch (e: Throwable) {
            false
        }
    }

    // Izin dianggap siap kalau Aksesibilitas, Notifikasi, dan Baterai beres. Nyala otomatis hanya kemudahan tambahan
    private fun izinOk(): Boolean = ClaimService.inst != null && notifOn() && batteryOk()

    // Kepala baris yang bisa dilipat: label di kiri, panah di kanan yang berputar
    private fun accHead(label: String, extra: View?): Pair<LinearLayout, ImageView> {
        val hd = LinearLayout(this)
        hd.orientation = LinearLayout.HORIZONTAL
        hd.gravity = Gravity.CENTER_VERTICAL
        hd.minimumHeight = dp(56)
        hd.addView(tv(label, 16f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (extra != null) hd.addView(extra, LinearLayout.LayoutParams(dp(22), dp(22)))
        val chev = iconView(this, R.drawable.ic_chev_down, C_MUT)
        val cp = LinearLayout.LayoutParams(dp(20), dp(20))
        cp.leftMargin = dp(12)
        hd.addView(chev, cp)
        attachRowPress(hd)
        return Pair(hd, chev)
    }

    private fun settings(): View {
        val (sv, col) = page()

        // ----- Izin (dilipat; terbuka sendiri kalau ada yang belum beres) -----
        val svc = tv("", 15f, false, C_MUT)
        tvSvc = svc
        val bat = tv("", 15f, false, C_MUT)
        tvBat = bat
        val auto = tv("", 15f, false, C_MUT)
        tvAuto = auto
        val notif = tv("", 15f, false, C_MUT)
        tvNotif = notif

        val gl = iconView(this, R.drawable.ic_check, C_SOFT)
        izinIcon = gl
        val (izinHead, izinChev) = accHead("Izin", gl)
        val izinBody = LinearLayout(this)
        izinBody.orientation = LinearLayout.VERTICAL
        izinBody.addView(divider())
        izinBody.addView(linkRow("Aksesibilitas", svc) { openAccessibility() })
        izinBody.addView(divider())
        izinBody.addView(linkRow("Nyala otomatis", auto) { showAutoInfo() })
        izinBody.addView(divider())
        izinBody.addView(
            linkRow("Notifikasi", notif) {
                try {
                    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    startActivity(i)
                } catch (e: Exception) {
                    toast("Tidak bisa dibuka: " + e.javaClass.simpleName)
                }
            }
        )
        izinBody.addView(divider())
        izinBody.addView(
            linkRow("Baterai", bat) {
                // Belum tanpa batasan: tampilkan dialog "Izinkan". Sudah tanpa batasan: buka daftar untuk meninjau
                val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    askBattery()
                } else {
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e: Exception) {
                        toast("Tidak bisa dibuka: " + e.javaClass.simpleName)
                    }
                }
            }
        )
        var izinOpen = !izinOk()
        izinBody.visibility = if (izinOpen) View.VISIBLE else View.GONE
        izinChev.rotation = if (izinOpen) 180f else 0f
        izinHead.setOnClickListener {
            izinOpen = !izinOpen
            setExpanded(izinBody, izinOpen, true)
            izinChev.animate().rotation(if (izinOpen) 180f else 0f).setDuration(280).setInterpolator(easeOut()).start()
        }
        col.addView(card(izinHead, izinBody), lpw(0, 4))

        // ----- Klaim -----
        val gv = tv(gameShort(), 14f, false, C_MUT)
        gv.setSingleLine(true)
        val afterBox = LinearLayout(this)
        afterBox.orientation = LinearLayout.VERTICAL
        afterBox.setPadding(0, dp(12), 0, dp(12))
        afterBox.addView(tv("Setelah selesai", 16f))
        val afterSeg = seg(listOf("Klaim VG", "Home", "Tetap di game"), Prefs.afterDone - 1, 44, 13f) { k -> Prefs.afterDone = k + 1 }
        afterBox.addView(afterSeg, lpw(44, 10))

        val rb = LinearLayout(this)
        rb.orientation = LinearLayout.HORIZONTAL
        rb.gravity = Gravity.CENTER_VERTICAL
        rb.addView(numBox(Prefs.serverMin.toString(), 80) { t -> t.trim().toIntOrNull()?.let { Prefs.serverMin = it } })
        val dash = tv("–", 16f, false, C_MUT)
        dash.setPadding(dp(8), 0, dp(8), 0)
        rb.addView(dash)
        rb.addView(numBox(Prefs.serverMax.toString(), 80) { t -> t.trim().toIntOrNull()?.let { Prefs.serverMax = it } })

        col.addView(
            section(
                "Klaim",
                card(
                    linkRow("Aplikasi game", gv) { pickGame(gv) }, divider(),
                    afterBox, divider(),
                    switchRow("Lewati server di atas posisi sekarang", { Prefs.skipAbove }, { Prefs.skipAbove = it }), divider(),
                    switchRow("Titik melayang saat klaim", { Prefs.dotAuto }, { Prefs.dotAuto = it }), divider(),
                    switchRow("Klaim Verifikasi Usia", { Prefs.claimAge }, { Prefs.claimAge = it }), divider(),
                    row("Rentang server", rb)
                )
            ), lpw(0, 18)
        )

        // ----- Kirim BBC -----
        col.addView(
            section(
                "Kirim BBC",
                card(
                    row("Level server minimal", numBox(Prefs.bbcMinLevel.toString()) { t -> t.trim().toIntOrNull()?.let { Prefs.bbcMinLevel = it } }),
                    divider(),
                    linkRow("Data server akun", tv("Buka", 15f, true, C_ACC)) { showBbcData() }
                )
            ),
            lpw(0, 18)
        )

        // ----- Lanjutan (dilipat) -----
        val (lanHead, lanChev) = accHead("Lanjutan", null)
        val lanBody = LinearLayout(this)
        lanBody.orientation = LinearLayout.VERTICAL
        lanBody.addView(divider())
        lanBody.addView(row("Jeda antar langkah (ms)", numBox(Prefs.stepMs.toString()) { t -> Prefs.stepMs = t.trim().toIntOrNull() ?: 0 }))
        lanBody.addView(divider())
        lanBody.addView(row("Waktu tunggu lobby (ms)", numBox(Prefs.lobbyWait.toString()) { t -> Prefs.lobbyWait = t.trim().toIntOrNull() ?: 3000 }))
        lanBody.addView(divider())

        // Geser daftar server (hanya manual), dilipat lagi di dalam Lanjutan
        val (swHead, swChev) = accHead("Geser daftar server", null)
        val swBody = LinearLayout(this)
        swBody.orientation = LinearLayout.VERTICAL
        fun field(label: String, get: () -> Int, set: (Int) -> Unit) {
            val e = numBox(get().toString()) { s ->
                val n = s.trim().toIntOrNull()
                if (n != null) set(n)
            }
            swipeFields.add(Pair(e, get))
            if (swBody.childCount > 0) swBody.addView(divider())
            swBody.addView(row(label, e))
        }
        field("Geser cepat: durasi (ms)", { Prefs.swipeHardMs }) { Prefs.swipeHardMs = it }
        field("Geser cepat: awal (% tinggi)", { Prefs.swipeStart }) { Prefs.swipeStart = it }
        field("Geser cepat: akhir (% tinggi)", { Prefs.swipeEnd }) { Prefs.swipeEnd = it }
        field("Geser pelan: durasi (ms)", { Prefs.swipeSlowMs }) { Prefs.swipeSlowMs = it }
        field("Geser pelan: awal (% tinggi)", { Prefs.swipeSlowStart }) { Prefs.swipeSlowStart = it }
        field("Geser pelan: akhir (% tinggi)", { Prefs.swipeSlowEnd }) { Prefs.swipeSlowEnd = it }
        field("Geser balik: durasi (ms)", { Prefs.swipeBackMs }) { Prefs.swipeBackMs = it }
        field("Geser balik: awal (% tinggi)", { Prefs.swipeBackStart }) { Prefs.swipeBackStart = it }
        field("Geser balik: akhir (% tinggi)", { Prefs.swipeBackEnd }) { Prefs.swipeBackEnd = it }
        field("Posisi X (% lebar)", { Prefs.swipeX }) { Prefs.swipeX = it }
        field("Jumlah server (uji)", { Prefs.testCount }) { Prefs.testCount = it }
        val bb = LinearLayout(this)
        bb.orientation = LinearLayout.HORIZONTAL
        bb.setPadding(0, dp(12), 0, dp(12))
        val t1 = btn("Uji sampai bawah", true) {
            Engine.diagnose(applicationContext, true)
            toast("Buka Daftar Karakter, pindah ke game dalam 15 detik, lalu diam")
        }
        val t2 = btn("Bawaan") {
            Prefs.resetSwipe()
            for ((e, g) in swipeFields) e.setText(g().toString())
        }
        val p1 = LinearLayout.LayoutParams(0, dp(48), 1f)
        p1.setMargins(0, 0, dp(4), 0)
        val p2 = LinearLayout.LayoutParams(0, dp(48), 1f)
        p2.setMargins(dp(4), 0, 0, 0)
        bb.addView(t1, p1)
        bb.addView(t2, p2)
        swBody.addView(divider())
        swBody.addView(bb)
        swBody.visibility = View.GONE
        var swOpen = false
        swHead.setOnClickListener {
            swOpen = !swOpen
            setExpanded(swBody, swOpen, true)
            swChev.animate().rotation(if (swOpen) 180f else 0f).setDuration(280).setInterpolator(easeOut()).start()
        }
        lanBody.addView(swHead)
        lanBody.addView(swBody)
        lanBody.addView(divider())
        val resetBtn = btn("Ulangi dari awal") {
            confirmDialog("Hapus catatan klaim hari ini?", "Hapus") {
                Prefs.resetDone()
                Prefs.resetAge()
                toast("Catatan dihapus")
            }
        }
        val rbp = lpw(48, 12)
        rbp.bottomMargin = dp(12)
        lanBody.addView(resetBtn, rbp)
        lanBody.visibility = View.GONE
        var lanOpen = false
        lanHead.setOnClickListener {
            lanOpen = !lanOpen
            setExpanded(lanBody, lanOpen, true)
            lanChev.animate().rotation(if (lanOpen) 180f else 0f).setDuration(280).setInterpolator(easeOut()).start()
            if (lanOpen) {
                // Gulir pelan supaya isi yang baru terbuka terlihat
                sv.postDelayed({ sv.smoothScrollBy(0, dp(160)) }, 120)
            }
        }
        col.addView(card(lanHead, lanBody), lpw(0, 18))
        return sv
    }

    // ---------- dialog kaca ----------

    private fun dialogW(frac: Float): Int = (resources.displayMetrics.widthPixels * frac).toInt()

    // Konfirmasi singkat sebelum menghapus
    private fun confirmDialog(msg: String, okLabel: String, act: () -> Unit) {
        val gd = GlassDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(22), dp(22), dp(16))
        box.background = popBg(28)
        box.addView(tv(msg, 16f))
        val bb = LinearLayout(this)
        bb.orientation = LinearLayout.HORIZONTAL
        val b1 = btn("Batal") { gd.dismiss() }
        val b2 = btn(okLabel, true) {
            gd.dismiss()
            act()
        }
        val q1 = LinearLayout.LayoutParams(0, dp(48), 1f)
        q1.setMargins(0, 0, dp(4), 0)
        val q2 = LinearLayout.LayoutParams(0, dp(48), 1f)
        q2.setMargins(dp(4), 0, 0, 0)
        bb.addView(b1, q1)
        bb.addView(b2, q2)
        box.addView(bb, lpw(0, 20))
        gd.show(box, dialogW(0.86f), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
    }

    // Cara memberi izin sekali supaya Aksesibilitas menyala sendiri
    private fun showAutoInfo() {
        val gd = GlassDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(20), dp(22), dp(16))
        box.background = popBg(28)
        box.addView(tv("Nyala otomatis", 20f, true))
        val ok = AutoAccess.granted(applicationContext)
        box.addView(
            tv(
                if (ok) "Izin sudah diberikan. Aksesibilitas akan dinyalakan sendiri tiap aplikasi dibuka atau saat Mulai ditekan."
                else "Berikan izin ini satu kali lewat Shizuku atau ADB, supaya Aksesibilitas tidak perlu dinyalakan manual lagi. Izin bertahan sampai aplikasi di-uninstall.",
                14f, false, C_MUT
            ), lpw(0, 8)
        )
        val cmd = tv(AutoAccess.command(applicationContext), 13f)
        cmd.typeface = Typeface.MONOSPACE
        cmd.setTextIsSelectable(true)
        cmd.setPadding(dp(14), dp(12), dp(14), dp(12))
        cmd.background = shape(Color.argb(14, 255, 255, 255), C_LINE, 16, 1f)
        box.addView(cmd, lpw(0, 14))
        val bb = LinearLayout(this)
        bb.orientation = LinearLayout.HORIZONTAL
        val b1 = btn("Salin perintah") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("perintah", AutoAccess.command(applicationContext)))
            sysToast("Perintah disalin")
        }
        val b2 = btn("Tutup", true) { gd.dismiss() }
        val q1 = LinearLayout.LayoutParams(0, dp(48), 1f)
        q1.setMargins(0, 0, dp(4), 0)
        val q2 = LinearLayout.LayoutParams(0, dp(48), 1f)
        q2.setMargins(dp(4), 0, 0, 0)
        bb.addView(b1, q1)
        bb.addView(b2, q2)
        box.addView(bb, lpw(0, 16))
        gd.show(box, dialogW(0.92f), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
    }

    // Daftar akun pengirim yang punya catatan server terpakai; hapus per akun atau semuanya
    private fun showBbcData() {
        val gd = GlassDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(20), dp(22), dp(14))
        box.background = popBg(28)
        box.addView(tv("Data server Kirim BBC", 20f, true))
        box.addView(tv("Akun yang pernah dipakai kirim dan server yang tercatat. Hapus kalau akun itu bisa dipakai kirim lagi.", 13f, false, C_MUT), lpw(0, 4))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        fun confirm(msg: String, act: () -> Unit) {
            if (Engine.running) {
                sysToast("Hentikan dulu proses yang berjalan")
                return
            }
            confirmDialog(msg, "Hapus", act)
        }
        lateinit var fill: () -> Unit
        fill = {
            list.removeAllViews()
            // Pesanan yang sedang berjalan (belum selesai)
            val pid = Prefs.bbcPendId
            val pend = LinearLayout(this)
            pend.orientation = LinearLayout.VERTICAL
            pend.setPadding(0, dp(10), 0, dp(10))
            pend.addView(tv("Pesanan berjalan", 16f, true))
            if (pid.isEmpty()) {
                pend.addView(tv("Tidak ada pesanan yang belum selesai", 13f, false, C_MUT), lpw(0, 2))
            } else {
                pend.addView(
                    tv("ID " + pid + ": terkirim " + Prefs.fmt(Prefs.bbcPendSent) + " dari " + Prefs.fmt(Prefs.bbcPendTarget) + " BBC", 13f, false, C_MUT),
                    lpw(0, 2)
                )
                val delP = tv("Hapus pesanan", 15f, true, C_ACC)
                delP.setPadding(0, dp(10), 0, dp(4))
                attachRowPress(delP)
                delP.setOnClickListener {
                    confirm("Hapus catatan pesanan ke ID " + pid + "? Hitungan terkirim kembali ke nol.") {
                        Prefs.bbcClearPending()
                        sysToast("Pesanan dihapus")
                        tick()
                        fill()
                    }
                }
                pend.addView(delP)
            }
            list.addView(pend)
            list.addView(divider())
            val accts = Prefs.bbcAccounts()
            if (accts.isEmpty()) {
                list.addView(tv("Belum ada catatan.", 15f, false, C_MUT), lpw(0, 12))
            }
            for (i in accts.indices) {
                val (id, names) = accts[i]
                if (i > 0) list.addView(divider())
                val rowV = LinearLayout(this)
                rowV.orientation = LinearLayout.VERTICAL
                rowV.setPadding(0, dp(10), 0, dp(10))
                rowV.addView(tv("ID " + id + ": " + names.size + " server", 16f, true))
                val last = Prefs.bbcLast(id)
                val sub = (if (names.isEmpty()) "Belum ada server tercatat" else names.joinToString(", ")) +
                    (if (last.isNotEmpty()) "\nTerakhir dipakai: " + last else "")
                rowV.addView(tv(sub, 13f, false, C_MUT), lpw(0, 2))
                val del = tv("Hapus data akun ini", 15f, true, C_ACC)
                del.setPadding(0, dp(10), 0, dp(4))
                attachRowPress(del)
                del.setOnClickListener {
                    confirm("Hapus catatan server akun " + id + "?") {
                        Prefs.bbcClearUsed(id)
                        sysToast("Data akun dihapus")
                        fill()
                    }
                }
                rowV.addView(del)
                list.addView(rowV)
            }
        }
        fill()
        val sv = ScrollView(this)
        sv.addView(list)
        val svp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        svp.topMargin = dp(8)
        box.addView(sv, svp)
        val bb = LinearLayout(this)
        bb.orientation = LinearLayout.HORIZONTAL
        val b1 = btn("Hapus semua") {
            confirm("Hapus catatan server SEMUA akun?") {
                Prefs.bbcClearAllUsed()
                sysToast("Semua data dihapus")
                fill()
            }
        }
        val b2 = btn("Tutup", true) { gd.dismiss() }
        val q1 = LinearLayout.LayoutParams(0, dp(48), 1f)
        q1.setMargins(0, 0, dp(4), 0)
        val q2 = LinearLayout.LayoutParams(0, dp(48), 1f)
        q2.setMargins(dp(4), 0, 0, 0)
        bb.addView(b1, q1)
        bb.addView(b2, q2)
        val bp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bp.topMargin = dp(12)
        box.addView(bb, bp)
        gd.show(box, dialogW(0.92f), (resources.displayMetrics.heightPixels * 0.78f).toInt(), Gravity.CENTER)
    }

    private fun pickGame(label: TextView) {
        var apps = Engine.listApps(this, false)
        if (apps.isEmpty()) apps = Engine.listApps(this, true)
        val gd = GlassDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(20), dp(22), dp(12))
        box.background = popBg(28)
        box.addView(tv("Pilih game", 20f, true))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        fun item(title: String, sub: String, pkg: String) {
            if (list.childCount > 0) list.addView(divider())
            val rowV = LinearLayout(this)
            rowV.orientation = LinearLayout.VERTICAL
            rowV.gravity = Gravity.CENTER_VERTICAL
            rowV.minimumHeight = dp(60)
            rowV.setPadding(0, dp(8), 0, dp(8))
            rowV.addView(tv(title, 16f, false, if (Prefs.pkg == pkg) C_ACC else C_FG))
            if (sub.isNotEmpty()) rowV.addView(tv(sub, 13f, false, C_MUT))
            attachRowPress(rowV)
            rowV.setOnClickListener {
                Prefs.pkg = pkg
                label.text = gameShort()
                gd.dismiss()
            }
            list.addView(rowV)
        }
        item("Otomatis (cari Mobile Legends)", "", "")
        for (a in apps) item(a.second, a.first, a.first)
        val sv = ScrollView(this)
        sv.addView(list)
        val svp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        svp.topMargin = dp(8)
        box.addView(sv, svp)
        gd.show(box, dialogW(0.9f), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
    }

    // ---------- halaman Fungsi pengaturan (bantuan), masuk dari kanan ----------

    private val helpItems = listOf(
        "Aksesibilitas" to "Layanan yang dipakai untuk screenshot dan ketukan. Harus aktif. Nyalakan lagi setelah memasang pembaruan, atau pakai Nyala otomatis.",
        "Nyala otomatis" to "Kalau izin WRITE_SECURE_SETTINGS sudah diberikan satu kali lewat Shizuku atau ADB, aplikasi menyalakan Aksesibilitasnya sendiri tiap dibuka dan saat Mulai ditekan. Ketuk barisnya untuk melihat dan menyalin perintahnya. Izin bertahan sampai aplikasi di-uninstall.",
        "Notifikasi" to "Izin notifikasi diminta saat aplikasi pertama dibuka. Kalau pernah ditolak, ketuk barisnya untuk membuka pengaturan notifikasi aplikasi dan mengizinkannya. Tanpa izin ini, notifikasi berjalan dan tombol Berhenti di notifikasi tidak tampil.",
        "Papan ketik" to "Papan ketik ditutup dan fokus dilepas dari kotak isian saat tombol Selesai di papan ketik ditekan, saat layar di luar kotak diketuk, saat Mulai ditekan, dan saat aplikasi ditinggalkan. Papan ketik tidak muncul sendiri saat aplikasi dibuka lagi.",
        "Baterai" to "Tanpa batasan supaya sistem tidak membatasi kecepatan baca layar. Dialog Izinkan muncul sekali saat aplikasi pertama dibuka; sesudah itu ketuk barisnya untuk memunculkannya lagi. Pengaturan baterai khusus merek HP (aktivitas latar belakang) tetap perlu dicek manual.",
        "Aplikasi game" to "Pilih aplikasi Mobile Legends yang dibuka bot.",
        "Jumlah server" to "Isi jumlah semua server akun ini, termasuk server yang sedang dipakai (awalnya 20). Wajib diisi. Bot terus mencari sampai semua server terlihat, dan tidak berhenti sebelum itu.",
        "Topup" to "Di Beranda, Klaim VG. Kalau aktif, di tiap server sesudah semua klaim selesai dan sebelum pindah ke server berikutnya, bot membeli 500 Diamond (bonus Top Up Pertama) dengan Vanguard Coin hasil klaim. Kalau Vanguard Coin kurang atau bonus server itu sudah terpakai, bot mencatatnya di log lalu lanjut pindah server. Menambah sekitar 6 sampai 10 detik per server.",
        "Setelah selesai" to "Yang dilakukan bot setelah semua server selesai. Klaim VG: langsung membuka aplikasi ini. Home: langsung ke layar Home. Tetap di game: kembali ke lobby dan tetap di game. Game tidak ditutup dan tidak dibuang dari Recents. Banner hasil klaim selalu tampil.",
        "Lewati server di atas posisi sekarang" to "Server yang urutannya di atas server awal dianggap sudah selesai dan tidak diklaim.",
        "Klaim Verifikasi Usia" to "Kalau aktif, di server pertama (SEKALI per akun) bot membuka Profil dan Youth Care, lalu mengerjakan verifikasi usia sampai hasil Dewasa (tanggal lahir 01/01/2001) dan kembali ke lobby. Di Kirim BBC: kalau Klaim dulu aktif, dikerjakan di server pertama sebelum klaim; kalau Klaim dulu mati, hanya di server pertama dan hanya saat ketahuan Vanguard Coin kurang untuk Top Up. Kalau menu Youth Care tidak ada, akun dianggap sudah terverifikasi dan dilewati. Sesudah itu, di tiap server bot juga mengklaim hadiah Verifikasi Usia di Event (satu kali per server): Klaim Semua, Gunakan sekarang, geser peti ke kartu Vanguard Coin, tombol +, Konfirmasi, lalu OK. Hasilnya Vanguard Coin 300. Kalau sudah diklaim atau menunya tidak ada, bot langsung lanjut.",
        "Titik melayang saat klaim" to "Titik tak terlihat yang membuat baca layar sekitar 10 kali lebih cepat. Gayanya dipilih lewat Diagnosa umum.",
        "Jeda antar langkah" to "Lama bot menunggu setelah tiap ketukan sebelum melihat layar lagi, dalam milidetik. 0 berarti tanpa jeda.",
        "Nomor server pertama dan terakhir" to "Hanya nomor server dalam rentang ini (awalnya 57092 sampai 57115) yang dianggap server. Nama yang kehilangan satu digit karena salah baca (misalnya s5094) diperbaiki otomatis kalau hanya ada satu kemungkinan, dan kalau tidak, barisnya diabaikan. Ubah kalau game menambah server.",
        "Kirim BBC" to "Pilih Kirim BBC di Beranda. Isi ID penerima, nick (nyalakan Cocokkan nick untuk memastikan akun yang dikirim benar, matikan untuk memilih hasil pencarian paling atas), Jumlah BBC (diisi dalam ribuan: 20 berarti 20k = 20.000 BBC), dan Jumlah server akun pengirim. Tiap server mengirim satu Yacht (1000 diamond = 1000 BBC): bot membeli 500 Diamond dengan Vanguard Coin bila diamond di lobby kurang dari 1000, mencari akun penerima lewat ID, lalu mengirim Yacht. Klaim dulu: klaim di tiap server sebelum kirim. Server yang sudah dipakai kirim diingat per akun pengirim. Kalau server di akun habis sebelum target tercapai, ganti akun lalu tekan Mulai kirim lagi: bot melanjutkan sisanya. Mulai dari server (kosong = mati): server bernomor lebih kecil dianggap sudah terpakai dan tidak dikunjungi, berguna untuk akun yang bonus Top Up Pertamanya sudah terpakai sampai nomor tertentu. Level server minimal (awalnya 15): server pertama di akun dicek dari angka di bawah nama pemain di lobby, server berikutnya dicek dari Daftar Karakter saat dipilih. Server yang levelnya kurang dilewati tanpa membelanjakan koin. Screenshot before.png dan after.png disimpan di Pictures/VGKlaim.",
        "Waktu tunggu lobby" to "Dalam milidetik. Dipakai hanya kalau lobby langsung muncul setelah loading tanpa popup apa pun: bot menunggu paling lama selama ini untuk popup. Begitu satu popup muncul dan ditutup, bot langsung lanjut. Kalau popup sudah muncul dan ditutup sebelum lobby, waktu ini dilewati.",
        "Geser daftar server" to "Geser cepat memuat server baru dan HANYA dipakai sekali, saat pertama mencari server baru di daftar yang baru dibuka. Sesudah itu bot hanya geser pelan. Geser pelan menggeser daftar maju. Geser balik menggeser daftar mundur, hanya kalau tidak ada server lama yang terlihat. Angka awal dan akhir adalah persen tinggi layar: 0 di atas, 100 di bawah. Uji sampai bawah: isi Jumlah server (uji), buka Daftar Karakter, tekan tombolnya, lalu pindah ke game. Bot terus menggeser sampai semua server terlihat dan melaporkan hasilnya.",
        "Diagnosa" to "Tombol Diagnosa di tab Log mengukur kecepatan baca layar (OCR) dan memilih gaya titik melayang. Untuk menguji geser daftar, pakai tombol Uji sampai bawah di bagian Geser daftar server.",
        "Data server akun" to "Di Pengaturan, bagian Kirim BBC. Menampilkan akun pengirim yang punya catatan server yang sudah dipakai kirim BBC. Hapus per akun atau semuanya kalau akun itu bisa dipakai kirim lagi. Di bagian atas dialog ada Pesanan berjalan (ID penerima, terkirim dari target) dengan tombol Hapus pesanan untuk memulai pesanan dari nol. Catatan tidak direset otomatis: kalau semua server akun sudah terpakai, bot berhenti dengan pesan Server di akun ini habis.",
        "Ulangi dari awal" to "Menghapus catatan server yang sudah selesai hari ini dan catatan verifikasi usia per akun."
    )

    private fun helpPage(): View {
        val (sv, col) = page(false)
        col.setPadding(dp(18), dp(8), dp(18), dp(24) + botInset)
        val items = ArrayList<View>()
        for (i in helpItems.indices) {
            val b = LinearLayout(this)
            b.orientation = LinearLayout.VERTICAL
            b.setPadding(0, dp(14), 0, dp(14))
            b.addView(tv(helpItems[i].first, 16f, true))
            val d = tv(helpItems[i].second, 14f, false, C_MUT)
            d.setLineSpacing(0f, 1.15f)
            b.addView(d, lpw(0, 4))
            items.add(b)
            if (i < helpItems.size - 1) items.add(divider())
        }
        col.addView(card(*items.toTypedArray()), lpw(0, 4))
        val w = tv(
            "Aplikasi ini tidak memiliki izin internet. Layanan Aksesibilitas hanya dipakai untuk screenshot dan ketukan " +
                "saat klaim berjalan. Matikan layanan ini setelah selesai dan jangan buka aplikasi bank saat aktif. " +
                "Memakai bot melanggar aturan game dan bisa membuat akun dikenai sanksi.",
            14f, false, C_MUT
        )
        w.setPadding(dp(12), 0, dp(12), 0)
        col.addView(w, lpw(0, 16))
        return sv
    }

    private fun openHelp() {
        val r = rootV ?: return
        if (helpOv != null) return
        hideKeyboard()
        val ov = FrameLayout(this)
        ov.setBackgroundColor(C_BG)
        ov.isClickable = true
        ov.addView(BackdropView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val colH = LinearLayout(this)
        colH.orientation = LinearLayout.VERTICAL
        colH.setPadding(0, topInset + dp(8), 0, 0)
        colH.addView(header("Fungsi pengaturan", false, true))
        colH.addView(helpPage(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        ov.addView(colH, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        r.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        helpOv = ov
        val w = (if (r.width > 0) r.width else resources.displayMetrics.widthPixels).toFloat()
        ov.translationX = w
        ov.animate().translationX(0f).setDuration(340).setInterpolator(easeOut()).start()
        bodyV?.animate()?.translationX(-w * 0.22f)?.alpha(0.5f)?.setDuration(340)?.setInterpolator(easeOut())?.start()
    }

    private fun closeHelp() {
        val ov = helpOv ?: return
        helpOv = null
        val w = (if (ov.width > 0) ov.width else resources.displayMetrics.widthPixels).toFloat()
        ov.animate().translationX(w).setDuration(280).setInterpolator(easeOut()).withEndAction {
            (ov.parent as? ViewGroup)?.removeView(ov)
        }.start()
        bodyV?.animate()?.translationX(0f)?.alpha(1f)?.setDuration(280)?.setInterpolator(easeOut())?.start()
    }

    // ---------- pembaruan tampilan tiap detik ----------

    private fun statusFor(m: Int): String {
        if (Engine.running && Engine.mode != m) return "Proses lain sedang berjalan"
        return Engine.status
    }

    // 0 = Mulai, 1 = Berhenti, 2 = Aktifkan Aksesibilitas dulu
    private fun actionState(m: Int): Int {
        if (Engine.running && Engine.mode == m) return 1
        if (ClaimService.inst == null && !AutoAccess.granted(applicationContext)) return 2
        return 0
    }

    private fun tick() {
        val total = Engine.total
        val done = Engine.doneCount
        val runC = Engine.running && Engine.mode == 0
        val runB = Engine.running && Engine.mode == 1

        // Klaim VG
        swapText(cStatus, statusFor(0))
        cProg?.text = if (total > 0) done.toString() + " dari " + total + " server" else done.toString() + " server"
        val fc = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
        if (fc != lastFracC) {
            cBar?.setFraction(fc, lastFracC >= 0f)
            lastFracC = fc
        }
        cDot?.turn(runC)
        cAct?.setState(actionState(0))

        // Kirim BBC
        swapText(bStatus, statusFor(1))
        val same = Prefs.bbcPendId == Prefs.bbcId.trim() && Prefs.bbcPendTarget > 0
        val tgt = if (same) Prefs.bbcPendTarget else Prefs.bbcAmount
        val sent = if (same) Prefs.bbcPendSent else 0
        bProg?.text = Prefs.fmt(sent) + " dari " + Prefs.fmt(tgt) + " BBC"
        val fb = if (tgt > 0) (sent.toFloat() / tgt).coerceIn(0f, 1f) else 0f
        if (fb != lastFracB) {
            bBar?.setFraction(fb, lastFracB >= 0f)
            lastFracB = fb
        }
        bDot?.turn(runB)
        bAct?.setState(actionState(1))

        // Jumlah server dipakai bersama di dua halaman: samakan isiannya kalau tidak sedang diketik
        val want = if (Prefs.serverCount > 0) Prefs.serverCount.toString() else ""
        for (f in cntFields) {
            if (!f.edit.hasFocus() && f.text() != want) f.setTextSilently(want)
        }

        tvLogStatus?.text = Engine.status + " | Jumlah: " + total + " server | Selesai: " + done

        val lg = tvLog
        if (lg != null) {
            val t = AppLog.text()
            if (t != lastLog) {
                lastLog = t
                val lsv = logScroll
                val atBottom = lsv == null || lsv.scrollY + lsv.height >= lg.height - dp(48)
                lg.text = t
                // Kalau sedang melihat baris terbaru, ikuti pelan ke bawah
                if (lsv != null && atBottom) lsv.post { lsv.smoothScrollTo(0, maxOf(0, lg.height - lsv.height)) }
            }
        }
        val svcT = tvSvc
        if (svcT != null) {
            if (ClaimService.inst != null) {
                svcT.text = "Aktif"
                svcT.setTextColor(C_ACC)
            } else {
                svcT.text = "Belum aktif"
                svcT.setTextColor(C_MUT)
            }
        }
        val au = tvAuto
        if (au != null) {
            if (AutoAccess.granted(applicationContext)) {
                au.text = "Siap"
                au.setTextColor(C_ACC)
            } else {
                au.text = "Perlu izin"
                au.setTextColor(C_MUT)
            }
        }
        val on = notifOn()
        val nn = tvNotif
        if (nn != null) {
            nn.text = if (on) "Diizinkan" else "Belum diizinkan"
            nn.setTextColor(if (on) C_ACC else C_MUT)
        }
        val bt = tvBat
        val batOk = batteryOk()
        if (bt != null) {
            bt.text = if (batOk) "Tanpa batasan" else "Belum diatur"
            bt.setTextColor(if (batOk) C_ACC else C_MUT)
        }

        // Ringkasan Izin: centang lembut kalau beres, tanda seru kalau ada yang kurang
        val ic = izinIcon
        if (ic != null) {
            val ok = ClaimService.inst != null && on && batOk
            val ns = if (ok) 1 else 2
            if (ns != izinState) {
                val first = izinState == 0
                izinState = ns
                val doApply = {
                    ic.setImageResource(if (ok) R.drawable.ic_check else R.drawable.ic_alert)
                    ic.imageTintList = ColorStateList.valueOf(if (ok) C_SOFT else C_FG)
                }
                if (first) {
                    doApply()
                } else {
                    ic.animate().alpha(0f).setDuration(120).withEndAction {
                        doApply()
                        ic.animate().alpha(1f).setDuration(200).start()
                    }.start()
                }
            }
        }
    }
}
