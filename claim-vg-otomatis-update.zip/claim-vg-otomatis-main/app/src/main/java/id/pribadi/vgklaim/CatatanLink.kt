package id.pribadi.vgklaim

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

// Sambungan ke aplikasi Catatan Cabang (com.catatan.cabang) lewat ContentProvider miliknya.
// Kalau Catatan Cabang tidak terpasang atau gagal dihubungi, semua panggilan dilewati diam-diam.
object CatatanLink {
    private const val AUTH = "content://com.catatan.cabang.bukti"

    private class P(val server: String?, val level: Int?, val note: String?)

    private val q = ArrayList<P>()
    private var warned = false

    // Satu pekerja di latar belakang: panggilan ke Catatan Cabang tidak lagi membuat mesin bot menunggu jawabannya
    private val exec = Executors.newSingleThreadExecutor { r ->
        val t = Thread(r, "catatan-link")
        t.isDaemon = true
        t
    }

    private fun log(m: String) = Engine.log(m)

    private fun call(method: String, arg: String, b: Bundle): Boolean {
        val ctx = Engine.app ?: return false
        return try {
            ctx.contentResolver.call(Uri.parse(AUTH), method, arg, b) != null
        } catch (e: Throwable) {
            if (!warned) {
                warned = true
                log("Catatan Cabang tidak terjangkau (" + e.javaClass.simpleName + "), pencatatan dilewati")
            }
            false
        }
    }

    // Level dan keterangan satu server. server = null berarti server yang sedang dimainkan (Engine.cur),
    // dipakai saat nama server awal belum diketahui. Kalau ID akun atau nama server belum ada, ditahan dulu.
    fun report(server: String?, level: Int?, note: String?) {
        if (level == null && note.isNullOrBlank()) return
        // Nama server diambil sekarang (server yang sedang dimainkan), bukan saat dikirim nanti
        synchronized(q) { q.add(P(server ?: Engine.cur, level, note)) }
        flush()
    }

    // Hanya menjadwalkan pengiriman di latar belakang; tidak menunggu jawaban Catatan Cabang
    fun flush() {
        try {
            exec.execute { doFlush() }
        } catch (_: Throwable) {
        }
    }

    // Tunggu antrean terkirim (dipakai saat sesi berakhir supaya catatan terakhir tidak hilang), paling lama ms
    fun drain(ms: Long) {
        val latch = CountDownLatch(1)
        try {
            exec.execute {
                doFlush()
                latch.countDown()
            }
        } catch (_: Throwable) {
            return
        }
        try {
            latch.await(ms, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
        }
    }

    private fun doFlush() {
        val acct = Engine.acct
        if (acct == "-") return
        val snapshot = synchronized(q) { ArrayList(q) }
        for (p in snapshot) {
            val sv = p.server ?: Engine.cur ?: continue
            val b = Bundle()
            b.putString("server", sv.removePrefix("s"))
            if (p.level != null) b.putString("level", p.level.toString())
            if (!p.note.isNullOrBlank()) b.putString("keterangan", p.note)
            val t0 = SystemClock.elapsedRealtime()
            val ok = call("server", acct, b)
            val ms = SystemClock.elapsedRealtime() - t0
            if (ok) {
                log("Catatan Cabang: akun " + acct + " server " + sv.removePrefix("s") +
                    (if (p.level != null) " level " + p.level else "") +
                    (if (!p.note.isNullOrBlank()) " ket \"" + p.note + "\"" else "") + " (" + ms + " ms, latar belakang)")
            }
            synchronized(q) { q.remove(p) }
        }
    }

    // Catatan pesanan Kirim BBC (satu pesanan ke satu ID penerima)
    fun order(key: String, id: String, nick: String, target: Int, sent: Int, server: String?, done: Boolean) {
        val b = Bundle()
        if (id.isNotBlank()) b.putString("id", id)
        if (nick.isNotBlank()) b.putString("nick", nick)
        if (target > 0) b.putString("target", target.toString())
        b.putString("sent", sent.toString())
        if (!server.isNullOrBlank()) b.putString("server", server)
        if (done) b.putString("done", "true")
        call("order", key, b)
    }

    // Foto before / after, dikirim sebagai JPEG kualitas 80
    fun photo(key: String, kind: String, bmp: Bitmap) {
        val ctx = Engine.app ?: return
        try {
            val uri = Uri.parse(AUTH + "/foto/" + key + "/" + kind + ".jpg")
            val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: return
            out.use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            log("Foto " + kind + " dikirim ke Catatan Cabang")
        } catch (e: Throwable) {
            if (!warned) {
                warned = true
                log("Foto tidak terkirim ke Catatan Cabang (" + e.javaClass.simpleName + ")")
            }
        }
    }
}
