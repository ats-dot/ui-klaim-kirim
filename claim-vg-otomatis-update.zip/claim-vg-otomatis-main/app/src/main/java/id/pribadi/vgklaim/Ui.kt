package id.pribadi.vgklaim

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

// Tema tunggal: Obsidian Glass (hitam, kaca, perak)
internal val C_BG = Color.parseColor("#050608")
internal val C_FG = Color.parseColor("#F2F4F8")
internal val C_MUT = Color.parseColor("#8B91A0")
internal val C_DIV = Color.argb(22, 255, 255, 255)
internal val C_POP = Color.argb(250, 20, 22, 28)
internal val C_LINE = Color.argb(46, 255, 255, 255)
internal val C_ACC = Color.parseColor("#EEF0F5")
internal val C_ACC2 = Color.parseColor("#A3A9B6")
internal val C_ONACC = Color.parseColor("#0A0B0E")
internal val C_SOFT = Color.parseColor("#9AA0AE")

internal fun easeOut() = PathInterpolator(0.32f, 0.72f, 0f, 1f)

internal fun easeIn() = PathInterpolator(0.4f, 0f, 1f, 1f)

// ---------- kaca ----------

// Kaca: isi transparan miring, kilau diagonal, garis tepi terang di kiri-atas, dan garis cahaya tipis di tepi atas dalam.
// lift (0..1) menambah kilau saat disentuh.
internal class GlassDrawable(private val r: Float, private val hair: Float, private val base: Int = 0) : Drawable() {
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val litP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var liftAnim: ValueAnimator? = null

    var lift = 0f
        set(v) {
            field = v
            invalidateSelf()
        }

    init {
        basePaint.color = base
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = hair
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = hair
        rim.strokeCap = Paint.Cap.ROUND
        litP.color = Color.WHITE
    }

    fun liftTo(to: Float) {
        liftAnim?.cancel()
        val a = ValueAnimator.ofFloat(lift, to)
        a.duration = if (to > 0f) 90L else 260L
        a.interpolator = easeOut()
        a.addUpdateListener { lift = it.animatedValue as Float }
        a.start()
        liftAnim = a
    }

    override fun onBoundsChange(b: Rect) {
        val w = b.width().toFloat()
        val ht = b.height().toFloat()
        rect.set(hair / 2f, hair / 2f, w - hair / 2f, ht - hair / 2f)
        fill.shader = LinearGradient(
            0f, 0f, w, ht,
            intArrayOf(Color.argb(24, 255, 255, 255), Color.argb(6, 255, 255, 255), Color.argb(10, 255, 255, 255)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        gloss.shader = LinearGradient(
            0f, 0f, w * 0.75f, ht,
            intArrayOf(Color.argb(24, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.5f), Shader.TileMode.CLAMP
        )
        edge.shader = LinearGradient(
            0f, 0f, w, ht,
            intArrayOf(Color.argb(128, 255, 255, 255), Color.argb(18, 255, 255, 255), Color.argb(8, 255, 255, 255), Color.argb(66, 255, 255, 255)),
            floatArrayOf(0f, 0.36f, 0.64f, 1f), Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(74, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        val sv = c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        if (Color.alpha(base) > 0) c.drawRoundRect(rect, r, r, basePaint)
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, gloss)
        if (lift > 0f) {
            litP.alpha = (lift * 26f).toInt().coerceIn(0, 255)
            c.drawRoundRect(rect, r, r, litP)
        }
        c.drawRoundRect(rect, r, r, edge)
        val x0 = r * 0.9f
        val x1 = b.width() - r * 0.9f
        if (x1 - x0 > hair * 4f) c.drawLine(x0, hair * 1.7f, x1, hair * 1.7f, rim)
        c.restoreToCount(sv)
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// Latar kotak isian: fokus memudar halus, dan bisa berkedip terang untuk menandai isian yang kurang
internal class FieldDrawable(private val r: Float, private val strokeW: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var focusT = 0f
    private var alertT = 0f
    private var fa: ValueAnimator? = null
    private var aa: ValueAnimator? = null

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = strokeW
    }

    override fun onBoundsChange(b: Rect) {
        rect.set(strokeW / 2f, strokeW / 2f, b.width() - strokeW / 2f, b.height() - strokeW / 2f)
    }

    fun setFocused(f: Boolean) {
        fa?.cancel()
        val a = ValueAnimator.ofFloat(focusT, if (f) 1f else 0f)
        a.duration = 170
        a.interpolator = easeOut()
        a.addUpdateListener {
            focusT = it.animatedValue as Float
            invalidateSelf()
        }
        a.start()
        fa = a
    }

    fun pulse() {
        aa?.cancel()
        alertT = 1f
        invalidateSelf()
        val a = ValueAnimator.ofFloat(1f, 0f)
        a.duration = 900
        a.interpolator = easeOut()
        a.addUpdateListener {
            alertT = it.animatedValue as Float
            invalidateSelf()
        }
        a.start()
        aa = a
    }

    override fun draw(c: Canvas) {
        val fa2 = 10f + 30f * focusT + 50f * alertT
        val la = 41f + 109f * focusT + 110f * alertT
        fill.color = Color.argb(fa2.toInt().coerceIn(0, 255), 255, 255, 255)
        line.color = Color.argb(la.toInt().coerceIn(0, 255), 255, 255, 255)
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, line)
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// Latar: hitam dengan cahaya lembut dari bawah dan sedikit kebiruan di kiri-atas
internal class BackdropView(ctx: Context) : View(ctx) {
    private val base = Paint()
    private val g1 = Paint()
    private val g2 = Paint()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        base.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.parseColor("#07080B"), Color.parseColor("#030304"), Shader.TileMode.CLAMP)
        g1.shader = RadialGradient(w / 2f, h * 1.06f, w * 1.0f, Color.argb(46, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        g2.shader = RadialGradient(w * 0.1f, -h * 0.02f, w * 0.9f, Color.argb(26, 190, 205, 255), Color.argb(0, 190, 205, 255), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, base)
        c.drawRect(0f, 0f, w, h, g1)
        c.drawRect(0f, 0f, w, h, g2)
    }
}

// Bilah progres perak yang bergerak halus
internal class GlowBar(ctx: Context) : View(ctx) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var frac = 0f
    private var anim: ValueAnimator? = null

    init {
        track.color = Color.argb(22, 255, 255, 255)
    }

    fun setFraction(f: Float, animate: Boolean) {
        val t = f.coerceIn(0f, 1f)
        anim?.cancel()
        if (!animate || width == 0) {
            frac = t
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(frac, t)
        a.duration = 650
        a.interpolator = easeOut()
        a.addUpdateListener {
            frac = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fillP.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, C_ACC2, C_ACC, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        c.drawRoundRect(0f, 0f, w, h, r, r, track)
        if (frac > 0f) {
            val fw = maxOf(h, w * frac)
            c.drawRoundRect(0f, 0f, fw, h, r, r, fillP)
        }
    }
}

// Saklar kaca: nyala = jalur perak dengan bulatan gelap. Area sentuh 60x44dp, bulatan melebar saat ditekan
internal class GlassSwitch(ctx: Context) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private var t = 0f
    private var pressT = 0f
    private var anim: ValueAnimator? = null
    private var pAnim: ValueAnimator? = null
    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knobP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ev = ArgbEvaluator()
    private val d = ctx.resources.displayMetrics.density

    init {
        strokeP.style = Paint.Style.STROKE
        strokeP.strokeWidth = 1.2f * d
        isClickable = true
        setOnClickListener { toggle() }
    }

    fun set(v: Boolean) {
        checked = v
        t = if (v) 1f else 0f
        invalidate()
    }

    private fun toggle() {
        checked = !checked
        anim?.cancel()
        val a = ValueAnimator.ofFloat(t, if (checked) 1f else 0f)
        a.duration = 380
        a.interpolator = OvershootInterpolator(1.4f)
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onChange?.invoke(checked)
    }

    private fun pressTo(to: Float) {
        pAnim?.cancel()
        val a = ValueAnimator.ofFloat(pressT, to)
        a.duration = 130
        a.interpolator = easeOut()
        a.addUpdateListener {
            pressT = it.animatedValue as Float
            invalidate()
        }
        a.start()
        pAnim = a
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> pressTo(1f)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressTo(0f)
        }
        return super.onTouchEvent(e)
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = "android.widget.Switch"
        info.isCheckable = true
        info.isChecked = checked
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension((60 * d).toInt(), (44 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val tw = 54f * d
        val th = 32f * d
        val ox = (width - tw) / 2f
        val oy = (height - th) / 2f
        val r = th / 2f
        val tc = t.coerceIn(0f, 1f)
        trackP.color = ev.evaluate(tc, Color.argb(13, 255, 255, 255), C_ACC) as Int
        c.drawRoundRect(ox, oy, ox + tw, oy + th, r, r, trackP)
        strokeP.color = ev.evaluate(tc, Color.argb(46, 255, 255, 255), Color.argb(0, 255, 255, 255)) as Int
        c.drawRoundRect(ox + 0.6f * d, oy + 0.6f * d, ox + tw - 0.6f * d, oy + th - 0.6f * d, r, r, strokeP)
        knobP.color = ev.evaluate(tc, Color.parseColor("#C8CCD6"), Color.parseColor("#0B0C10")) as Int
        val kr = 12f * d
        val kw = 2f * kr + pressT * 3f * d
        val left = ox + 3f * d + t * (tw - 6f * d - kw)
        val cy = oy + th / 2f
        c.drawRoundRect(left, cy - kr, left + kw, cy + kr, kr, kr, knobP)
    }
}

// Chip kaca dengan penanda: cincin = mati, titik putih menyala = aktif
internal class ToggleChip(ctx: Context, private val label: String) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private val d = ctx.resources.displayMetrics.density
    private val glass = GlassDrawable(22f * d, d)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val litP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private var t = 0f
    private var anim: ValueAnimator? = null

    init {
        background = glass
        isClickable = true
        contentDescription = label
        textP.color = C_FG
        textP.typeface = Typeface.DEFAULT_BOLD
        textP.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 15f, ctx.resources.displayMetrics)
        ringP.style = Paint.Style.STROKE
        ringP.strokeWidth = 1.6f * d
        litP.style = Paint.Style.STROKE
        litP.strokeWidth = d
        setOnClickListener { toggle() }
    }

    fun set(v: Boolean) {
        checked = v
        t = if (v) 1f else 0f
        invalidate()
    }

    private fun toggle() {
        checked = !checked
        anim?.cancel()
        val a = ValueAnimator.ofFloat(t, if (checked) 1f else 0f)
        a.duration = 260
        a.interpolator = easeOut()
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onChange?.invoke(checked)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).setInterpolator(easeOut()).start()
                glass.liftTo(1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.8f)).start()
                glass.liftTo(0f)
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = "android.widget.CheckBox"
        info.isCheckable = true
        info.isChecked = checked
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = (14f * d + 12f * d + 10f * d + textP.measureText(label) + 18f * d).toInt()
        setMeasuredDimension(w, (44f * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val cx = 20f * d
        val rad = 5.5f * d
        if (t < 1f) {
            ringP.color = Color.argb(((1f - t) * 255f).toInt().coerceIn(0, 255), 139, 145, 160)
            c.drawCircle(cx, cy, rad - 0.8f * d, ringP)
        }
        if (t > 0f) {
            haloP.color = Color.argb((70f * t).toInt().coerceIn(0, 255), 255, 255, 255)
            c.drawCircle(cx, cy, rad + 3f * d * t, haloP)
            fillP.color = Color.argb((t * 255f).toInt().coerceIn(0, 255), 242, 244, 248)
            c.drawCircle(cx, cy, rad * (0.35f + 0.65f * t), fillP)
            litP.color = Color.argb((60f * t).toInt().coerceIn(0, 255), 255, 255, 255)
            rr.set(d / 2f, d / 2f, width - d / 2f, height - d / 2f)
            c.drawRoundRect(rr, 22f * d, 22f * d, litP)
        }
        val fm = textP.fontMetrics
        c.drawText(label, 36f * d, cy - (fm.ascent + fm.descent) / 2f, textP)
    }
}

// Titik status: cincin saat berhenti, titik putih berdenyut halus saat berjalan
internal class StatusDot(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private var pulse = 0f
    private var tA: ValueAnimator? = null
    private var pA: ValueAnimator? = null
    var on = false
        private set

    init {
        ringP.style = Paint.Style.STROKE
        ringP.strokeWidth = 1.6f * d
    }

    fun turn(v: Boolean) {
        if (v == on) return
        on = v
        tA?.cancel()
        val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
        a.duration = 260
        a.interpolator = easeOut()
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        a.start()
        tA = a
        if (v) startPulse() else stopPulse()
    }

    private fun startPulse() {
        if (!ValueAnimator.areAnimatorsEnabled()) return
        pA?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1600
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = easeOut()
        a.addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
        a.start()
        pA = a
    }

    private fun stopPulse() {
        pA?.cancel()
        pA = null
        pulse = 0f
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (on && pA == null) startPulse()
    }

    override fun onDetachedFromWindow() {
        pA?.cancel()
        pA = null
        super.onDetachedFromWindow()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension((18f * d).toInt(), (18f * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rad = 5.5f * d
        if (t < 1f) {
            ringP.color = Color.argb(((1f - t) * 255f).toInt().coerceIn(0, 255), 139, 145, 160)
            c.drawCircle(cx, cy, rad - 0.8f * d, ringP)
        }
        if (t > 0f) {
            fillP.color = Color.argb((t * 255f).toInt().coerceIn(0, 255), 242, 244, 248)
            c.drawCircle(cx, cy, rad * (0.35f + 0.65f * t), fillP)
            if (on && pulse > 0f) {
                haloP.color = Color.argb(((1f - pulse) * 80f).toInt().coerceIn(0, 255), 255, 255, 255)
                c.drawCircle(cx, cy, rad + pulse * 3.5f * d, haloP)
            }
        }
    }
}

// Kotak isian dengan label yang naik ke atas saat terisi atau difokus
internal class FloatField(
    ctx: Context,
    labelText: String,
    numeric: Boolean,
    value: String,
    private val hideKb: () -> Unit,
    private val onChange: (String) -> Unit
) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = FieldDrawable(26f * d, maxOf(1f, d))
    val label = TextView(ctx)
    val edit = EditText(ctx)
    private var floated = false
    private var silent = false

    init {
        background = bg
        label.text = labelText
        label.setTextColor(C_MUT)
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        label.setSingleLine(true)
        label.pivotX = 0f
        label.pivotY = 0f
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL)
        lp.leftMargin = (18f * d).toInt()
        addView(label, lp)

        edit.setText(value)
        edit.hint = labelText
        edit.setHintTextColor(Color.TRANSPARENT)
        edit.setTextColor(C_FG)
        edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        edit.typeface = Typeface.DEFAULT_BOLD
        edit.background = null
        edit.gravity = Gravity.BOTTOM or Gravity.START
        edit.setPadding((18f * d).toInt(), (20f * d).toInt(), (14f * d).toInt(), (6.3f * d).toInt())
        edit.setSingleLine(true)
        edit.inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        edit.imeOptions = EditorInfo.IME_ACTION_DONE
        edit.setOnEditorActionListener { _, _, _ ->
            hideKb()
            true
        }
        edit.setOnFocusChangeListener { _, has ->
            bg.setFocused(has)
            refresh(true)
        }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!silent) onChange(s?.toString() ?: "")
                refresh(true)
            }
        })
        addView(edit, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        refresh(false)
    }

    private fun refresh(animate: Boolean) {
        val f = edit.hasFocus() || edit.text.isNotEmpty()
        if (animate && f == floated) return
        floated = f
        val ty = if (f) -10.3f * d else 0f
        val sc = if (f) 0.69f else 1f
        val ea = if (f) 1f else 0f
        if (animate) {
            label.animate().translationY(ty).scaleX(sc).scaleY(sc).setDuration(180).setInterpolator(easeOut()).start()
            edit.animate().alpha(ea).setDuration(160).start()
        } else {
            label.translationY = ty
            label.scaleX = sc
            label.scaleY = sc
            edit.alpha = ea
        }
    }

    fun text(): String = edit.text.toString()

    fun setTextSilently(s: String) {
        silent = true
        edit.setText(s)
        silent = false
        refresh(true)
    }

    // Tandai isian yang kurang: bergetar, berkedip terang, lalu fokus
    fun alert() {
        bg.pulse()
        shake(this, 7f * d)
        edit.requestFocus()
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(edit, 0)
        } catch (e: Throwable) {
        }
    }
}

// Tombol aksi tunggal: Mulai / Berhenti / Aktifkan Aksesibilitas, berganti dengan pudar halus
internal class ActionButton(ctx: Context, private val startLabel: String) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val primary = Button(ctx)
    private val stopB = Button(ctx)
    private val stopGlass = GlassDrawable(29f * d, d)
    private var state = -1
    var onStart: (() -> Unit)? = null
    var onStop: (() -> Unit)? = null
    var onEnable: (() -> Unit)? = null

    init {
        val pill = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C_ACC, C_ACC2))
        pill.cornerRadius = 29f * d
        style(primary, startLabel, C_ONACC)
        primary.background = pill
        attachPress(primary, 0.97f, null)
        style(stopB, "BERHENTI", C_FG)
        stopB.background = stopGlass
        attachPress(stopB, 0.97f, stopGlass)
        stopB.alpha = 0f
        stopB.visibility = View.INVISIBLE
        addView(primary, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (58f * d).toInt()))
        addView(stopB, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (58f * d).toInt()))
        primary.setOnClickListener {
            if (state == 2) onEnable?.invoke() else onStart?.invoke()
        }
        stopB.setOnClickListener { onStop?.invoke() }
    }

    private fun style(b: Button, text: String, color: Int) {
        b.text = text
        b.isAllCaps = false
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        b.setTypeface(null, Typeface.BOLD)
        b.letterSpacing = 0.02f
        b.setTextColor(color)
        b.stateListAnimator = null
        b.minHeight = 0
        b.minimumHeight = 0
    }

    fun setState(s: Int) {
        if (s == state) return
        val prev = state
        state = s
        val label = if (s == 2) "AKTIFKAN AKSESIBILITAS" else startLabel
        val showStop = s == 1
        if (prev < 0) {
            primary.text = label
            primary.alpha = if (showStop) 0f else 1f
            primary.visibility = if (showStop) View.INVISIBLE else View.VISIBLE
            stopB.alpha = if (showStop) 1f else 0f
            stopB.visibility = if (showStop) View.VISIBLE else View.INVISIBLE
            return
        }
        val prevStop = prev == 1
        if (showStop != prevStop) {
            if (showStop) {
                fadeOut(primary)
                fadeIn(stopB)
            } else {
                primary.text = label
                fadeOut(stopB)
                fadeIn(primary)
            }
        } else if (!showStop) {
            primary.animate().alpha(0.15f).setDuration(80).withEndAction {
                primary.text = label
                primary.animate().alpha(1f).setDuration(160).start()
            }.start()
        }
    }

    private fun fadeIn(v: View) {
        v.visibility = View.VISIBLE
        v.animate().alpha(1f).setDuration(220).setInterpolator(easeOut()).start()
    }

    private fun fadeOut(v: View) {
        v.animate().alpha(0f).setDuration(160).withEndAction {
            if (v.alpha == 0f) v.visibility = View.INVISIBLE
        }.start()
    }
}

// Tahan tombol untuk mengulang (stepper). Sentuhan singkat tetap ditangani klik biasa
internal class RepeatTouch(
    private val h: Handler,
    private val glass: GlassDrawable?,
    private val step: () -> Unit
) : View.OnTouchListener {
    private var repeating = false
    private var justRepeated = false
    private val run = object : Runnable {
        override fun run() {
            repeating = true
            step()
            h.postDelayed(this, 85)
        }
    }

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                repeating = false
                justRepeated = false
                h.postDelayed(run, 420)
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).setInterpolator(easeOut()).start()
                glass?.liftTo(1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                h.removeCallbacks(run)
                justRepeated = repeating
                repeating = false
                v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2f)).start()
                glass?.liftTo(0f)
            }
        }
        return false
    }

    fun consumeClick(): Boolean {
        val j = justRepeated
        justRepeated = false
        return j
    }
}

// ---------- ikon ----------

// Ikon tab bergaris tipis, digambar lewat kode: 0 = rumah, 1 = log, 2 = roda gigi
internal class TabIcon(ctx: Context, private val kind: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = C_MUT
    }

    fun tint(c: Int) {
        p.color = c
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val s = width / 24f
        c.save()
        c.scale(s, s)
        p.strokeWidth = 1.7f
        when (kind) {
            0 -> {
                val path = Path()
                path.moveTo(4f, 11f)
                path.lineTo(12f, 4f)
                path.lineTo(20f, 11f)
                path.lineTo(20f, 19.5f)
                path.lineTo(15f, 19.5f)
                path.lineTo(15f, 14f)
                path.lineTo(9f, 14f)
                path.lineTo(9f, 19.5f)
                path.lineTo(4f, 19.5f)
                path.close()
                c.drawPath(path, p)
            }
            1 -> {
                c.drawRoundRect(RectF(4f, 3.5f, 20f, 20.5f), 3f, 3f, p)
                c.drawLine(8f, 8.5f, 16f, 8.5f, p)
                c.drawLine(8f, 12f, 16f, 12f, p)
                c.drawLine(8f, 15.5f, 13f, 15.5f, p)
            }
            else -> {
                c.drawCircle(12f, 12f, 3.2f, p)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4.0
                    val ca = Math.cos(a).toFloat()
                    val sa = Math.sin(a).toFloat()
                    c.drawLine(12f + 6.6f * ca, 12f + 6.6f * sa, 12f + 9f * ca, 12f + 9f * sa, p)
                }
            }
        }
        c.restore()
    }
}

// Ikon vektor berwarna (dipakai untuk centang, panah, plus, minus, bantuan)
internal fun iconView(ctx: Context, res: Int, color: Int): ImageView {
    val iv = ImageView(ctx)
    iv.setImageResource(res)
    iv.imageTintList = ColorStateList.valueOf(color)
    iv.scaleType = ImageView.ScaleType.FIT_CENTER
    iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    return iv
}

// ---------- gerak ----------

internal fun shake(v: View, amp: Float) {
    val a = ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, -amp, amp, -amp * 0.7f, amp * 0.7f, -amp * 0.4f, amp * 0.4f, 0f)
    a.duration = 400
    a.start()
}

// Umpan balik tekan untuk tombol dan kartu kaca: mengecil sedikit, kilau naik, lalu memantul kembali
internal fun attachPress(v: View, scaleTo: Float, glass: GlassDrawable?) {
    v.setOnTouchListener { view, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                view.animate().scaleX(scaleTo).scaleY(scaleTo).setDuration(100).setInterpolator(easeOut()).start()
                glass?.liftTo(1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                view.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.6f)).start()
                glass?.liftTo(0f)
            }
        }
        false
    }
}

// Umpan balik tekan untuk baris: meredup sebentar
internal fun attachRowPress(v: View) {
    v.isClickable = true
    v.setOnTouchListener { view, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> view.animate().alpha(0.55f).setDuration(70).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().alpha(1f).setDuration(260).start()
        }
        false
    }
}

// Lipat / buka isi dengan tinggi yang bergerak halus
internal fun setExpanded(v: View, expand: Boolean, animate: Boolean) {
    (v.tag as? ValueAnimator)?.cancel()
    val lp = v.layoutParams
    val parent = v.parent as? ViewGroup
    if (!animate || parent == null || parent.width == 0) {
        v.visibility = if (expand) View.VISIBLE else View.GONE
        v.alpha = 1f
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
        v.layoutParams = lp
        return
    }
    if (expand) {
        val w = parent.width - parent.paddingLeft - parent.paddingRight
        v.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val target = v.measuredHeight
        val from = if (v.visibility == View.VISIBLE) v.height else 0
        lp.height = from
        v.layoutParams = lp
        v.visibility = View.VISIBLE
        val a = ValueAnimator.ofInt(from, target)
        a.duration = 300
        a.interpolator = easeOut()
        a.addUpdateListener {
            lp.height = it.animatedValue as Int
            v.layoutParams = lp
            v.alpha = it.animatedFraction
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (cancelled) return
                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                v.layoutParams = lp
                v.alpha = 1f
            }
        })
        v.tag = a
        a.start()
    } else {
        val from = v.height
        val a = ValueAnimator.ofInt(from, 0)
        a.duration = 240
        a.interpolator = easeOut()
        a.addUpdateListener {
            lp.height = it.animatedValue as Int
            v.layoutParams = lp
            v.alpha = 1f - it.animatedFraction
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (cancelled) return
                v.visibility = View.GONE
                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                v.layoutParams = lp
                v.alpha = 1f
            }
        })
        v.tag = a
        a.start()
    }
}

// ---------- dialog kaca ----------

// Dialog kaca: latar meredup halus, kotak naik dan membesar halus, keluar lebih cepat. Blur latar bila perangkat mendukung
internal class GlassDialog(private val act: Activity) {
    private val dlg = Dialog(act)
    private val rootV = FrameLayout(act)
    private val scrim = View(act)
    private var box: View? = null
    private var closing = false
    private val dens = act.resources.displayMetrics.density

    private fun blurTo(v: Int) {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                dlg.window?.setBackgroundBlurRadius(v)
            } catch (e: Throwable) {
            }
        }
    }

    private fun blurAnim(from: Int, to: Int, ms: Long) {
        if (Build.VERSION.SDK_INT < 31) return
        val a = ValueAnimator.ofInt(from, to)
        a.duration = ms
        a.addUpdateListener { blurTo(it.animatedValue as Int) }
        a.start()
    }

    fun show(content: View, w: Int, h: Int, gravity: Int) {
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        scrim.setBackgroundColor(Color.argb(150, 0, 0, 0))
        scrim.alpha = 0f
        rootV.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        content.isClickable = true
        content.alpha = 0f
        content.scaleX = 0.94f
        content.scaleY = 0.94f
        content.translationY = 16f * dens
        rootV.addView(content, FrameLayout.LayoutParams(w, h, gravity))
        scrim.setOnClickListener { dismiss() }
        dlg.setContentView(rootV)
        dlg.setOnKeyListener { _, keyCode, ev ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (ev.action == KeyEvent.ACTION_UP) dismiss()
                true
            } else {
                false
            }
        }
        dlg.window?.let { win ->
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            win.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
            win.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
        box = content
        dlg.show()
        scrim.animate().alpha(1f).setDuration(240).start()
        content.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(280).setInterpolator(easeOut()).start()
        blurAnim(0, 30, 280)
    }

    fun dismiss() {
        if (closing) return
        closing = true
        box?.animate()?.alpha(0f)?.scaleX(0.96f)?.scaleY(0.96f)?.translationY(10f * dens)?.setDuration(170)?.setInterpolator(easeIn())?.start()
        blurAnim(30, 0, 190)
        scrim.animate().alpha(0f).setDuration(190).withEndAction {
            try {
                dlg.dismiss()
            } catch (e: Throwable) {
            }
        }.start()
    }
}
