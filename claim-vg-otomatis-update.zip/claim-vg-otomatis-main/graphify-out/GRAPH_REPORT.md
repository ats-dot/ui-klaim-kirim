# Peta Struktur & Rangkuman Proyek

## `build.gradle.kts` (4 baris)

## `settings.gradle.kts` (16 baris)

## `app/build.gradle.kts` (32 baris)

## `app/src/main/AndroidManifest.xml` (57 baris)

## `app/src/main/java/id/pribadi/vgklaim/AppLog.kt` (24 baris)
- Baris 7: `object AppLog`
- Baris 12: `fun add`
- Baris 18: `fun text`
- Baris 21: `fun clear`

## `app/src/main/java/id/pribadi/vgklaim/AutoAccess.kt` (39 baris)
- Baris 10: `object AutoAccess`
- Baris 13: `fun granted`
- Baris 15: `fun command`
- Baris 18: `fun ensure`

## `app/src/main/java/id/pribadi/vgklaim/BbcEngine.kt` (1170 baris)
- Baris 11: `object BbcEngine`
- Baris 14: `class Skip`
- Baris 36: `fun log`
- Baris 37: `fun now`
- Baris 38: `fun sleepMs`
- Baris 39: `fun cap`
- Baris 40: `fun tapXY`
- Baris 41: `fun tapLine`
- Baris 44: `fun quickTap`
- Baris 52: `fun backAndWait`
- Baris 62: `fun waitFor`
- Baris 75: `fun validate`
- Baris 84: `fun bannerText`
- Baris 92: `fun setupOrder`
- Baris 115: `fun rowLevel`
- Baris 125: `fun belowStart`
- Baris 137: `fun levelOk`
- Baris 152: `fun onLobbyDetected`
- Baris 166: `fun lobbyLevel`
- Baris 178: `fun main`
- Baris 188: `fun captureProblem`
- Baris 196: `fun run`
- Baris 310: `fun markUsed`
- Baris 321: `fun sendOnServer`
- Baris 411: `fun tapRetry`
- Baris 423: `fun clearLobbyPopups`
- Baris 436: `fun openFromLobby`
- Baris 467: `fun blueIconLeftOf`
- Baris 487: `fun lobbyDiamonds`
- Baris 502: `fun firstBadge`
- Baris 526: `fun ensureDiamonds`
- Baris 554: `fun isTopUp`
- Baris 556: `fun rpMode`
- Baris 561: `fun topUpOnly`
- Baris 581: `fun priceLine`
- Baris 589: `fun dialogDump`
- Baris 593: `fun buyDiamonds`
- Baris 701: `fun closeSquadPopup`
- Baris 721: `fun openFriendDialog`
- Baris 732: `fun typeId`
- Baris 741: `fun fillId`
- Baris 781: `fun keyboardUp`
- Baris 786: `fun okLine`
- Baris 789: `fun waitKeyboardGone`
- Baris 803: `fun commitKeyboard`
- Baris 820: `fun pressOke`
- Baris 826: `fun isLightKey`
- Baris 837: `fun digitKeys`
- Baris 886: `fun typeByKeyboard`
- Baris 905: `fun closeKeyboard`
- Baris 917: `fun rowCands`
- Baris 923: `fun firstRowSig`
- Baris 927: `fun searchAndOpen`
- Baris 945: `fun openProfileFull`
- Baris 958: `fun openLiveStream`
- Baris 991: `fun panelDiamonds`
- Baris 1003: `fun yachtPoint`
- Baris 1017: `fun yachtDialogByPrice`
- Baris 1024: `fun sendYacht`
- Baris 1061: `fun toLobby`
- Baris 1078: `fun normNick`
- Baris 1092: `fun lev`
- Baris 1107: `fun nickInText`
- Baris 1125: `fun nickMatch`
- Baris 1141: `fun saveShot`

## `app/src/main/java/id/pribadi/vgklaim/ClaimService.kt` (456 baris)
- Baris 30: `class ClaimService`
- Baris 47: `fun onServiceConnected`
- Baris 52: `fun onAccessibilityEvent`
- Baris 54: `fun onInterrupt`
- Baris 56: `fun onUnbind`
- Baris 61: `fun onDestroy`
- Baris 66: `fun errName`
- Baris 76: `fun shot`
- Baris 87: `fun onSuccess`
- Baris 112: `fun onFailure`
- Baris 144: `fun banner`
- Baris 188: `fun dot`
- Baris 235: `fun notifyDone`
- Baris 254: `fun tap`
- Baris 260: `fun swipe`
- Baris 270: `fun clickInputOk`
- Baris 296: `fun findOkNode`
- Baris 308: `fun keyboardVisible`
- Baris 316: `fun inputText`
- Baris 355: `fun findEditable`
- Baris 366: `fun back`
- Baris 370: `fun home`
- Baris 374: `fun recents`
- Baris 379: `fun swipeHold`
- Baris 393: `fun swipeSegments`
- Baris 412: `fun gesture`
- Baris 415: `fun gestureStroke`
- Baris 425: `fun onCompleted`
- Baris 430: `fun onCancelled`

## `app/src/main/java/id/pribadi/vgklaim/Engine.kt` (2829 baris)
- Baris 9: `object Engine`
- Baris 17: `class Stop`
- Baris 58: `class Reg`
- Baris 96: `fun start`
- Baris 123: `fun stop`
- Baris 132: `fun applyPerf`
- Baris 140: `fun releasePerf`
- Baris 144: `fun dotName`
- Baris 153: `fun runMain`
- Baris 197: `fun now`
- Baris 199: `fun log`
- Baris 201: `fun alive`
- Baris 206: `fun sleepMs`
- Baris 221: `fun sleepS`
- Baris 223: `fun speed`
- Baris 225: `fun rect`
- Baris 233: `fun setBlind`
- Baris 239: `fun clearBlind`
- Baris 244: `fun cap`
- Baris 334: `fun resetStats`
- Baris 343: `fun statLine`
- Baris 356: `fun stepWait`
- Baris 362: `fun tapXY`
- Baris 391: `fun tapLine`
- Baris 393: `fun back`
- Baris 399: `fun doSwipe`
- Baris 414: `fun doSwipeHold`
- Baris 429: `fun swipe`
- Baris 434: `fun isLobby`
- Baris 440: `fun eventOpen`
- Baris 445: `fun fixSrv`
- Baris 468: `fun serverNums`
- Baris 484: `fun isServerList`
- Baris 487: `fun readCurrent`
- Baris 503: `fun setAccount`
- Baris 518: `fun parseProfile`
- Baris 520: `fun parseProfileLines`
- Baris 529: `fun readProfileInfo`
- Baris 550: `fun parseRole`
- Baris 559: `fun readRole`
- Baris 568: `fun readAccountId`
- Baris 583: `fun isAccount`
- Baris 589: `fun akunTab`
- Baris 598: `fun featurePopup`
- Baris 601: `fun isProfile`
- Baris 605: `fun tapArrow`
- Baris 611: `fun tapX`
- Baris 634: `fun popups`
- Baris 642: `fun waitMasteryCode`
- Baris 656: `fun closeHeroGuide`
- Baris 665: `fun popupsRaw`
- Baris 715: `fun awaitLobby`
- Baris 794: `fun lum`
- Baris 801: `fun maxLum`
- Baris 822: `fun darkPopupX`
- Baris 866: `fun settleLobby`
- Baris 887: `fun closeRemainingPopups`
- Baris 897: `fun backToLobby`
- Baris 926: `fun findGame`
- Baris 946: `fun listApps`
- Baris 966: `fun launch`
- Baris 978: `fun slowSwipe`
- Baris 983: `class Step`
- Baris 988: `fun rowH`
- Baris 997: `fun rangeText`
- Baris 1006: `class Sty`
- Baris 1017: `fun fastStyle`
- Baris 1030: `fun scrollStep`
- Baris 1074: `fun mergeRows`
- Baris 1096: `fun movedText`
- Baris 1104: `fun atFrontier`
- Baris 1109: `fun expectRows`
- Baris 1113: `fun beginList`
- Baris 1133: `fun pullOnce`
- Baris 1150: `fun settleWindow`
- Baris 1180: `fun scrollNext`
- Baris 1274: `fun scrollTop`
- Baris 1284: `fun tapAvatar`
- Baris 1298: `fun waitServerList`
- Baris 1314: `fun accountToList`
- Baris 1330: `fun profileToList`
- Baris 1354: `fun fastToList`
- Baris 1405: `fun openServerList`
- Baris 1478: `fun pickNext`
- Baris 1518: `fun switchTo`
- Baris 1551: `fun okDiff`
- Baris 1570: `fun confirmSwitch`
- Baris 1624: `fun waitEventOpen`
- Baris 1634: `fun eventTitle`
- Baris 1639: `fun waitScreenChange`
- Baris 1648: `fun pageTitle`
- Baris 1653: `fun waitHadiah`
- Baris 1676: `fun learnPetir`
- Baris 1695: `fun menuCount`
- Baris 1709: `fun openEvent`
- Baris 1716: `fun recoverShort`
- Baris 1813: `fun openMenu`
- Baris 1832: `fun okBtn`
- Baris 1834: `fun waitOk`
- Baris 1864: `fun claimLoop`
- Baris 1900: `fun waitPanel`
- Baris 1914: `fun countPx`
- Baris 1933: `fun coinGold`
- Baris 1937: `fun coinRed`
- Baris 1941: `fun coinGray`
- Baris 1949: `fun panelUp`
- Baris 1952: `fun claimCoin`
- Baris 2027: `fun btnGold`
- Baris 2046: `fun cancelPeti`
- Baris 2054: `fun claimAgePanel`
- Baris 2173: `class MenuTask`
- Baris 2177: `fun claimEvents`
- Baris 2231: `fun isDone`
- Baris 2233: `fun refreshCount`
- Baris 2241: `fun topUpStep`
- Baris 2246: `fun claimServer`
- Baris 2261: `fun openOwnApp`
- Baris 2270: `fun finishAction`
- Baris 2292: `fun doneText`
- Baris 2302: `fun showBanner`
- Baris 2311: `fun waitScr`
- Baris 2323: `fun webNext`
- Baris 2327: `fun isBlueBtn`
- Baris 2342: `fun ageVerifyOnce`
- Baris 2493: `fun main`
- Baris 2588: `fun timeOcr`
- Baris 2602: `fun one`
- Baris 2612: `fun diagStrips`
- Baris 2638: `fun diagPriority`
- Baris 2642: `fun measure`
- Baris 2681: `fun freshList`
- Baris 2695: `fun diagExtra`
- Baris 2716: `fun reachTest`
- Baris 2727: `fun reachRun`
- Baris 2774: `fun diagnose`

## `app/src/main/java/id/pribadi/vgklaim/KeepAliveService.kt` (77 baris)
- Baris 16: `class KeepAliveService`
- Baris 22: `fun start`
- Baris 31: `fun stop`
- Baris 39: `fun onBind`
- Baris 41: `fun onStartCommand`

## `app/src/main/java/id/pribadi/vgklaim/MainActivity.kt` (1769 baris)
- Baris 62: `fun easeOut`
- Baris 65: `class GlassDrawable`
- Baris 78: `fun onBoundsChange`
- Baris 99: `fun draw`
- Baris 111: `fun setAlpha`
- Baris 113: `fun setColorFilter`
- Baris 116: `fun getOpacity`
- Baris 120: `class BackdropView`
- Baris 125: `fun onSizeChanged`
- Baris 131: `fun onDraw`
- Baris 141: `class GlowBar`
- Baris 151: `fun setFraction`
- Baris 170: `fun onSizeChanged`
- Baris 174: `fun onDraw`
- Baris 187: `class GlassSwitch`
- Baris 206: `fun set`
- Baris 212: `fun toggle`
- Baris 227: `fun onMeasure`
- Baris 231: `fun onDraw`
- Baris 248: `class TabIcon`
- Baris 258: `fun tint`
- Baris 263: `fun onDraw`
- Baris 304: `class BackIcon`
- Baris 315: `fun onDraw`
- Baris 326: `class MainActivity`
- Baris 368: `fun run`
- Baris 374: `fun dp`
- Baris 376: `fun onCreate`
- Baris 389: `fun onRequestPermissionsResult`
- Baris 395: `fun askBattery`
- Baris 408: `fun askBatteryOnce`
- Baris 416: `fun askNotif`
- Baris 427: `fun hideKeyboard`
- Baris 437: `fun dispatchTouchEvent`
- Baris 449: `fun onResume`
- Baris 455: `fun onPause`
- Baris 462: `fun onBackPressed`
- Baris 473: `fun shape`
- Baris 481: `fun popBg`
- Baris 483: `fun silverPill`
- Baris 489: `fun styleBtn`
- Baris 499: `fun btn`
- Baris 521: `fun tv`
- Baris 530: `fun card`
- Baris 539: `fun divider`
- Baris 547: `fun row`
- Baris 560: `fun linkRow`
- Baris 566: `fun switchRow`
- Baris 573: `fun inputBg`
- Baris 588: `fun numBox`
- Baris 607: `fun beforeTextChanged`
- Baris 608: `fun onTextChanged`
- Baris 609: `fun afterTextChanged`
- Baris 618: `fun seg`
- Baris 658: `fun lpw`
- Baris 667: `fun section`
- Baris 679: `fun page`
- Baris 691: `fun toast`
- Baris 695: `fun header`
- Baris 727: `fun applyPos`
- Baris 755: `fun setThumb`
- Baris 760: `fun goTo`
- Baris 777: `class Pager`
- Baris 785: `fun onInterceptTouchEvent`
- Baris 818: `fun onTouchEvent`
- Baris 849: `fun buildDock`
- Baris 901: `fun render`
- Baris 977: `fun pageHome`
- Baris 993: `fun selectMode`
- Baris 1012: `fun statusCard`
- Baris 1025: `fun home`
- Baris 1064: `fun begin`
- Baris 1078: `fun run`
- Baris 1097: `fun textBox`
- Baris 1116: `fun beforeTextChanged`
- Baris 1117: `fun onTextChanged`
- Baris 1118: `fun afterTextChanged`
- Baris 1125: `fun bbcHome`
- Baris 1181: `fun pageLog`
- Baris 1189: `fun logTab`
- Baris 1235: `fun gameShort`
- Baris 1242: `fun pageSettings`
- Baris 1250: `fun settings`
- Baris 1339: `fun field`
- Baris 1402: `fun showAutoInfo`
- Baris 1448: `fun showBbcData`
- Baris 1459: `fun confirm`
- Baris 1561: `fun pickGame`
- Baris 1573: `fun item`
- Baris 1606: `fun showMenu`
- Baris 1658: `fun helpPage`
- Baris 1687: `fun statusFor`
- Baris 1692: `fun tick`

## `app/src/main/java/id/pribadi/vgklaim/Matcher.kt` (157 baris)
- Baris 9: `object Matcher`
- Baris 10: `class Tpl`
- Baris 11: `class Hit`
- Baris 16: `fun dir`
- Baris 22: `fun names`
- Baris 28: `fun reload`
- Baris 38: `fun gray`
- Baris 54: `fun has`
- Baris 57: `fun find`
- Baris 63: `fun findPrefix`
- Baris 73: `fun down`
- Baris 91: `fun sad`
- Baris 105: `fun search`

## `app/src/main/java/id/pribadi/vgklaim/Ocr.kt` (119 baris)
- Baris 11: `class Line`
- Baris 16: `class Scr`
- Baris 22: `fun has`
- Baris 24: `fun find`
- Baris 27: `fun same`
- Baris 34: `fun exact`
- Baris 36: `fun exactAll`
- Baris 39: `object Ocr`
- Baris 44: `fun norm`
- Baris 55: `fun read`
- Baris 101: `fun lev`

## `app/src/main/java/id/pribadi/vgklaim/Prefs.kt` (353 baris)
- Baris 9: `object Prefs`
- Baris 12: `fun init`
- Baris 16: `fun s`
- Baris 105: `fun ageVerified`
- Baris 107: `fun setAgeVerified`
- Baris 111: `fun resetAge`
- Baris 120: `fun fmt`
- Baris 122: `fun resetSwipe`
- Baris 195: `fun dayStamp`
- Baris 197: `fun dayKey`
- Baris 199: `fun doneToday`
- Baris 204: `fun addDone`
- Baris 210: `fun removeDone`
- Baris 217: `fun accountsDoneToday`
- Baris 222: `fun markAccountDone`
- Baris 229: `fun purgeOld`
- Baris 240: `fun resetDone`
- Baris 297: `fun bbcClearPending`
- Baris 302: `fun bbcUsed`
- Baris 307: `fun bbcAddUsed`
- Baris 314: `fun bbcAccounts`
- Baris 324: `fun bbcClearAllUsed`
- Baris 332: `fun bbcClearUsed`
- Baris 337: `fun bbcTry`
- Baris 339: `fun bbcSetTry`
- Baris 343: `fun bbcClearTry`
- Baris 348: `fun bbcLast`
- Baris 350: `fun bbcSetLast`

## `app/src/main/java/id/pribadi/vgklaim/TemplateActivity.kt` (195 baris)
- Baris 25: `class TemplateActivity`
- Baris 30: `fun dp`
- Baris 32: `fun onCreate`
- Baris 76: `fun bw`
- Baris 90: `fun onActivityResult`
- Baris 104: `fun doSave`
- Baris 121: `fun toast`
- Baris 123: `class SelView`
- Baris 139: `fun setBitmap`
- Baris 145: `fun onDraw`
- Baris 159: `fun onTouchEvent`
- Baris 182: `fun crop`

## `app/src/main/res/drawable/ic_launcher.xml` (5 baris)

## `app/src/main/res/drawable/ic_launcher_background.xml` (33 baris)

## `app/src/main/res/drawable/ic_launcher_foreground.xml` (88 baris)

## `app/src/main/res/drawable/ic_logo.xml` (10 baris)

## `app/src/main/res/drawable/ic_stat_vg.xml` (26 baris)

## `app/src/main/res/values/strings.xml` (4 baris)

## `app/src/main/res/xml/accessibility_config.xml` (9 baris)
